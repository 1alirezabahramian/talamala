# MANIFEST — Phase 1 Gate: CI hardening + OpenAPI parity

## Commit-allowed (apply to main / this stage)

| Path | Change |
|------|--------|
| `.github/workflows/ci.yml` | Fail-closed rewrite; exact-SHA smoke gates; pdo_sqlite; openapi-parity job |
| `backend/bin/openapi_parity_check.php` | **New** — fail-closed production route parity (excludes `/v1/dev/*`) |
| `docs/00-master/CURRENT_STATE.md` | Updated: gate CLOSED, next = Persistence-2 |
| `docs/00-master/STAGE_CI_OPENAPI_PARITY.md` | **New** — CI policy + route ↔ OpenAPI table |
| `docs/traceability/CAPABILITY_LEDGER.md` | CAP-016 + CAP-020 → IMPLEMENTED |

## Bundled-only / not for this commit

| Path | Reason |
|------|--------|
| `openapi/*.yaml` | Reference snapshot only — **no content change** this stage (already parity-aligned). Included so reviewer can run parity offline. |
| This MANIFEST + ZIP | Delivery artifact |

## Not included (out of scope)

- frontend/, AGENTS.md, Persistence-2
- Any Kimia write / price / settlement / payment
- Business behavior changes

## Expected tests after apply

```text
php backend/bin/http_smoke.php
→ PASS=33 FAIL=0

php backend/bin/persist_smoke.php
→ PASS=6 FAIL=0

php backend/bin/openapi_parity_check.php
→ PASS=21 FAIL=0
  parity OK
```

### CI jobs that must be green for a meaningful SHA
- `php-syntax`
- `http-smoke` (PASS=33 FAIL=0)
- `persist-smoke` (PASS=6 FAIL=0)
- `openapi-parity`
- `secret-scan`

`composer-check` is informational only (skeleton path without full vendor).

## Definition of Done checklist

- [x] CI fail-closed; failures not swallowed
- [x] http_smoke + persist_smoke exact-SHA gates
- [x] OpenAPI runtime parity; `/v1/dev/*` excluded
- [x] Parity tool fail-closed and in CI
- [x] Zero regression on existing smokes
- [x] Zero new API / feature / financial rule
- [x] ZIP scope + MANIFEST + expected tests
- [x] CURRENT_STATE updated; Next = Persistence-2
