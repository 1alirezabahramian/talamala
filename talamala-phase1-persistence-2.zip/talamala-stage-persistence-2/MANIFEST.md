# MANIFEST — Persistence-2: Session + Idempotency + Audit on SQLite

## Commit-allowed

| Path | Change |
|------|--------|
| `backend/app/Infrastructure/Persistence/Sqlite/SqliteConnection.php` | Schema: sessions, idempotency_keys, audit_events |
| `backend/app/Infrastructure/Persistence/Sqlite/SqliteSessionStore.php` | **New** |
| `backend/app/Infrastructure/Persistence/Sqlite/SqliteIdempotencyRegistry.php` | **New** |
| `backend/app/Infrastructure/Persistence/Sqlite/SqliteAuditLogger.php` | **New** |
| `backend/app/Http/Kernel.php` | Wire SQLite for audit/idempotency/sessions; init order fix |
| `backend/bin/persist_smoke.php` | +3 survival checks → PASS=9 |
| `.github/workflows/ci.yml` | persist gate PASS=9 FAIL=0 |
| `docs/00-master/STAGE_PERSISTENCE_2.md` | **New** stage doc |
| `docs/00-master/CURRENT_STATE.md` | Updated |
| `docs/traceability/CAPABILITY_LEDGER.md` | CAP-002 / CAP-003 notes |

## Bundled-only / not for this commit
- None beyond this MANIFEST + ZIP

## Not included
- frontend/, AGENTS.md
- OTP rate limiter / tenant resolver (still InMemory by design)
- Kimia Write / price / payment
- Any new API or financial rule
- GoldPlatform V2 Delta pricing/catalog (no blind port)

## Expected tests

```text
php backend/bin/http_smoke.php
→ PASS=33 FAIL=0

php backend/bin/persist_smoke.php
→ PASS=9 FAIL=0
  (session_survives_reboot, idempotency_survives_reboot, audit_survives_reboot)

php backend/bin/openapi_parity_check.php
→ PASS / parity OK
```

### CI jobs
- php-syntax
- http-smoke (33/0)
- persist-smoke (9/0)
- openapi-parity
- secret-scan

## Definition of Done
- [x] Sessions durable on SQLite
- [x] Idempotency durable on SQLite (tenant-scoped)
- [x] Audit durable on SQLite
- [x] Zero regression http_smoke 33/0
- [x] persist_smoke extended PASS=9
- [x] CI gate updated
- [x] No new API / financial rule
- [x] ZIP + MANIFEST
