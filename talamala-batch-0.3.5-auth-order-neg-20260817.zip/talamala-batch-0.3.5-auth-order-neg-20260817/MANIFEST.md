# MANIFEST — talamala-batch-0.3.5-auth-order-neg-20260817

**Base HEAD:** b45676b (0.3.4-phase1)  
**VERSION:** 0.3.5-phase1  
**Direction:** Harden identity + order API contracts with gated negatives (no GT invent)

## Stages
| # | Stage |
|---|--------|
| A | staff_login_bad_password → 401 |
| B | staff_login_credentials_required → 422 |
| C | otp_request_mobile_required → 422 |
| D | otp_verify_bad_code → 401 |
| E | order_accept_missing_quote_id → 422 |
| F | http_smoke PASS 54 → **59** + CI |
| G | OpenAPI customer accept 422 documented |
| H | docs / Ledger CAP-029 / VERSION 0.3.5-phase1 |

## Commit-allowed
- `.github/workflows/ci.yml`
- `VERSION` · `README.md` · `Makefile`
- `backend/bin/http_smoke.php`
- `openapi/customer-v1.openapi.yaml`
- `docs/00-master/*` listed · `docs/traceability/CAPABILITY_LEDGER.md`

## Expected
```text
php backend/bin/http_smoke.php → PASS=59 FAIL=0
php backend/bin/check.php      → ALL CHECKS PASSED
```

## Non-goals
Kimia Write · Pricing · Settlement · Payment · Delta · durable tenant resolver
