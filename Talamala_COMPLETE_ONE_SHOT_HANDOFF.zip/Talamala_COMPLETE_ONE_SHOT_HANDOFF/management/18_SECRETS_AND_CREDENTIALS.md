# Secrets / Credentials

This packet intentionally contains no usable production secret. Never
request the owner to paste secrets into chat or commit them to Git. Use
GitHub/environment secret storage and tenant-encrypted integration
settings. Mask logs and UI. Historical example API keys/phone
numbers/IDs are examples/evidence, never production configuration.
