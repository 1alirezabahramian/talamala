# Definition of Done

A capability is NOT done merely because code exists.

Applicable evidence: - requirement/source/ground truth - accepted ADR -
migration/data model - backend - API + OpenAPI - frontend -
permission/tenant boundary - audit - idempotency - tests executed -
exact-SHA CI green - PR review/merge - browser/runtime/visual
verification - documentation

Statuses and test statuses must use the vocabulary defined in the Master
Prompt. Production Ready is forbidden without exact release SHA gates
and production closure evidence.
