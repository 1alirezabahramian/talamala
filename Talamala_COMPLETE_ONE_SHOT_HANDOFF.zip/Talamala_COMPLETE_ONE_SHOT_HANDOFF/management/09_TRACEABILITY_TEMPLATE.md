# Traceability Template

For every capability create one row/document:

-   Capability ID
-   Requirement
-   Business owner/source
-   Ground-truth artifact/version/date
-   ADR
-   Data model/migration
-   Backend services
-   API route
-   OpenAPI operationId
-   Frontend screen/component
-   Permission
-   Audit event
-   Idempotency scope
-   Unit tests
-   Feature/integration tests
-   Browser/E2E tests
-   CI workflow/run
-   Exact SHA
-   PR
-   Merge SHA
-   Visual approval
-   Release evidence
-   Current status
-   Known gaps
