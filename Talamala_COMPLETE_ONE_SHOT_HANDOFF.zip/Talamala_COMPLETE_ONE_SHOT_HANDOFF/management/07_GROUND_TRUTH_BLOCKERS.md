# Ground Truth Blocker Register

## P0

-   Current official Kimia Swagger/OpenAPI file must be supplied as a
    raw artifact.
-   Kimia customer-create exact
    request/response/error/duplicate/readback.
-   Kimia write contracts for each intended financial operation.
-   Price provider official API + freshness/failover + business pricing
    coefficients/rounding.
-   Settlement/reconciliation/hold semantics.

## P1

-   Current BehPardakht Mellat merchant integration contract + sandbox
    credentials/process.
-   Goftino official widget/API/privacy contract.
-   SMS.ir tenant credential/template/live delivery configuration.
-   Jibit sandbox/live credentials and operational rate/error behavior.

## Rule

Until resolved, capability remains `BLOCKED BY GROUND TRUTH`; never fill
with "standard industry behavior".
