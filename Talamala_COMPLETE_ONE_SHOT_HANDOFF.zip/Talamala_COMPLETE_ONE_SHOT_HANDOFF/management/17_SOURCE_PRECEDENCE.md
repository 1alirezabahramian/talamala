# Source Precedence

Financial/Kimia: 1 real API output 2 official current Swagger/OpenAPI 3
accepted ADR/project memory 4 owner-confirmed rule/example 5 verified
historical code/evidence 6 general knowledge only for explanation

Development status: 1 current Talamala GitHub 2 exact branch/commit/PR 3
CI on same SHA 4 docs on same branch 5 this handoff packet 6 historical
GoldPlatform evidence

Contradiction between authoritative sources: stop affected sensitive
change, record contradiction/effect, ask owner only for the actual
decision.
