# Capability Ledger Bootstrap

The prior independent audit inventoried 87 capabilities across
architecture, tenant, identity, Kimia, pricing/quote, order/trade,
settlement/reconciliation, custody/delivery, admin/operator, tenant
settings, external integrations, customer frontend, backoffice frontend,
API/OpenAPI, tests/security and release/operations.

Talamala is greenfield: do not copy old completion percentages. Recreate
the ledger at Stage 0 using the same domains and the new repository's
actual evidence.

Mandatory columns: ID, Domain, Capability, Importance, Status,
GroundTruth, Source, ADR, DB, Backend, API, OpenAPI, Frontend,
Permission, Audit, Idempotency, Tests, CI_SHA, PR, Merge, Visual, Gap,
Blocker.
