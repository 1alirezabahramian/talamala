# AI / Team Operating Protocol

Safe independent work should proceed continuously. Stop only for: -
genuine owner business decision - contradictory authoritative sources -
financial/Kimia write without ground truth - destructive history
operation - sensitive CI/security failure needing a decision - external
credential/authorization

Do not manufacture stages, duplicate classes/contracts, or ask
repetitive questions. Every stage report: Status, Stage,
Branch/Base/Head/SHA/PR, Sources, Changed Files, Rules, Capabilities,
Backend, Frontend, API/OpenAPI, DB/Migrations, Tests, exact-SHA CI,
Docs, Duplicate/Drift, Gaps, Risks, Decision Needed, Next Step.
