# Manifest & SHA-256

  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  File                                                                                                      Bytes SHA-256
  ---------------------------------------------------------------------------------- ---------------------------- --------------------------------------------------------------------
  `00_START_HERE_MASTER_PROMPT.md`                                                                          23604 `963f8b89e9d94204c4ca0e2c2f98b6bfe680a8c3aebec1df1b377c29b08e5af6`

  `README.md`                                                                                                 974 `bca76cd717b37431aef30849e27f1bf1ac969da825caf6b4d8459f4737c6680e`

  `evidence/historical/00_PROJECT_MEMORY.md`                                                                42716 `37f796804c4cfb8472ea7c794d8c654776b6a2a203abd43262450748b89835d0`

  `evidence/historical/08_KIMIA_INTEGRATION_AUDIT.md`                                                       20138 `872a3c7128faa1d9ce548041866888a1c5fa8e3a6e3fda999d1ec7aa0543e254`

  `evidence/historical/41_GOLDPLATFORM_DOMAIN_WORKSHOP_2026-07-28.md`                                       33433 `670b3c16fcbc2215676024c239310e78a85f7af0a9f4c798b0543f0016a4103d`

  `evidence/historical/PROJECT_AUDIT_REQUEST.txt`                                                            2830 `79924eaca0deccc77fcfd15215c7ed60462e2ad9b0d688ab01c6e1c0fc60b3e6`

  `evidence/historical/gp.txt`                                                                             102100 `cad47d6ad9febf99a818f18a7296c5f94459279280a43b6bec62a7ab8e67abae`

  `management/07_GROUND_TRUTH_BLOCKERS.md`                                                                    828 `dc7dbd06f167f5eb66c586582957f262f33a42ac46c8fef12a56530c359e843d`

  `management/09_TRACEABILITY_TEMPLATE.md`                                                                    543 `ef3fc118dfd560887b470cd88a45f1084cf8db67423b08b22655f646afd4e23a`

  `management/14_DEFINITION_OF_DONE.md`                                                                       544 `a5268ed606b74d2a45a7ac5f4ddba0df0cfaf07a6cb2cd5d86b6885f8984f3dd`

  `management/15_AI_OPERATING_PROTOCOL.md`                                                                    657 `98920207cfc517054d128120487e98ea734408922b8634e626151ec4c3f9980f`

  `management/16_CAPABILITY_LEDGER_BOOTSTRAP.md`                                                              722 `e4d90ae1afa11fa0851e139429f892f083ec0d47bbd2038264ac09308441d0ad`

  `management/17_SOURCE_PRECEDENCE.md`                                                                        544 `0293c4aed0458ebd385698f860e523efff2928a29d3d55df0bf56d9dfbf98082`

  `management/18_SECRETS_AND_CREDENTIALS.md`                                                                  363 `1ae482032ec98e3fc5836301a4159c5df330f0edabdb0b0407729b7d3392a0ca`

  `provider-evidence/08_PROVIDER_REGISTER.md`                                                                2139 `fdf44d21f02ae73625e31eca971ca04d2a259ae3c643dd088f146d6961887210`

  `provider-evidence/GOFTINO_POLICY.md`                                                                       364 `c819b43e8504f39f96651ecf8be13d9cfc7e1b2da776c108759fa2fb2a0fbec0`

  `provider-evidence/JIBIT_USAGE_POLICY.md`                                                                   456 `3578d8b4a1b765da4df3aba8fe70682d381d261b236997840944b75c8cfa0259`

  `provider-evidence/KIMIA_VERIFIED_EXTRACT.md`                                                              2364 `e9a29f54e3bb9a333f54b7fe11f4ac23b492952db88718ab9a1b6d65d38de0a1`

  `provider-evidence/PAYMENT_GATEWAYS_POLICY.md`                                                              652 `ffc8739669f49fd64e175da163689f188099d519edbb2b693615fa12e0e1f0b0`

  `provider-evidence/PRICE_PROVIDER_POLICY.md`                                                                391 `6460eb2c8cfba7109f871feb8fb2fe9de6e1fe2833f6758711e8dfd249ca33e2`

  `provider-evidence/SMSIR_CONTRACT_EXTRACT.md`                                                              1155 `7829fd42cb1986b29ed256592c174dda13e386874110e4759b7ed7b09fa5852d`

  `provider-evidence/official/Jibit-Identicator_Project_(V1.5.2)-Tech-Persian.pdf`                        1274140 `b93576aeeefcc2693ae430b1a8c1fa857376b9e09337c896e8cfe7cc077301d8`

  `spec/01_ARCHITECTURE_BLUEPRINT.md`                                                                        1432 `2a898ae1d2b2d8ad1a25747c4d18ae42015a6d833b0a27e4bd77debf069fb6a6`

  `spec/02_DOMAIN_RULES.md`                                                                                  1665 `ab9b51ae8aacbb9520d0578e07e0f919bfc45762849091f6d39573f2e8d51036`

  `spec/03_API_OPENAPI_POLICY.md`                                                                             765 `c7d7949b87398cb0a732b6e3d978527b8016de45fb40d0f42a253348bd09de7f`

  `spec/04_UI_UX_SPEC.md`                                                                                    1435 `dce561b87a1e48156df15ac42f16388806315028e6878758ad4f58ec940ce802`

  `spec/05_ROADMAP.md`                                                                                        771 `37912604c18d58c8a220c0e2627e18c14a4da9713ca8027c5c9de5961d802626`

  `spec/06_PROJECT_TREE.md`                                                                                  1120 `aa73a8c8df7814278575ba7c2baf9fd9888b865e26dfd86e090fd88ba83bbb2e`

  `spec/10_SECURITY_CHECKLIST.md`                                                                             826 `83cec215a2b6e0b824afe0eb79c8f31a194b232731e82cdf02ff66398fe2c230`

  `spec/11_DATA_MODEL_BLUEPRINT.md`                                                                          1225 `7ccfa56733ee2fa51f5565ae3ac51d177aec47f0b31a1bad61aded1927fe8fab`

  `spec/12_BACKEND_ALGORITHM.md`                                                                             1375 `491cbcc67103692bcfdfa4e151043b44db2ccdc61c99940b516f382f304a9e22`

  `spec/13_FRONTEND_INFORMATION_ARCHITECTURE.md`                                                              856 `1c4d6ae9f88adb18538ed154d3a817662eb6a28ecb478f05ba661326f3afadec`
  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
