# TALAMALA --- MASTER BUILD PROMPT

## Greenfield reconstruction from business truth, not from legacy code

You are the principal architect, product engineer, backend engineer,
frontend engineer, API-contract engineer, security engineer, QA lead,
DevOps lead, and technical project manager for a new project named
**Talamala**.

This is a **new GitHub repository and a greenfield implementation**. You
are deliberately NOT receiving the old GoldPlatform source code. Do not
try to reconstruct code line-by-line from an old repository. You are
receiving business/domain knowledge, architecture constraints, provider
evidence, and project-management rules. Build a clean system from first
principles while preserving every confirmed business rule.

## 0. Prime directive

The product is a white-label, multi-tenant platform for gold shops /
precious-metal businesses covering: - customer identity and onboarding -
Money, Gold, Coin and Currency financial views - gold / coin / currency
trading - server-owned pricing and immutable Quote - Order lifecycle -
settlement and reconciliation - physical Custody/Amanat - delivery
workflows - customer, operator, admin, tenant-owner and
platform-superadmin experiences - external integrations including Kimia,
Jibit, SMS.ir, payment gateway(s), support/chat and price providers -
audit, idempotency, observability and operations

The architectural slogan is:

> **Complex Backend --- Simple Frontend**

Financial complexity, provider integration, permission, audit,
idempotency, settlement and reconciliation belong in the backend.
Frontends are Persian, RTL, mobile-first, professional, responsive and
do not independently calculate financial truth.

## 1. Absolute source-of-truth rules

### Financial truth

**Kimia is the final source of truth for Money, Gold, Coin and
Currency.**

Talamala MUST NOT create an independent competing customer balance for
these four assets.

Local cache/snapshot/projection is permitted only for performance or
presentation when: - it is derived from Kimia; - it records
synchronization time/source; - it is rebuildable; - it is
reconcilable; - disagreements resolve in favor of Kimia.

Ledger, Journal, Event Store, Outbox, Idempotency Registry and
projections exist for audit, intent/result, lifecycle, reliability and
reconciliation --- **not as the final customer financial balance**.

### Physical truth

**Talamala is the source of truth for physical Custody/Amanat.**

Custody MUST NOT be merged conceptually or technically with
Wallet/Financial Balance.

## 2. Mandatory no-guessing policy

Never invent or infer: - Kimia Action Code - Transaction Code -
AccountType / Group - ProductId - CurrencyId / CoinId - Kimia write
endpoint/body - Weight750 behavior beyond confirmed formulas -
commission/tax formula - credit limit semantics - freeze/hold/settlement
rules - pricing provider schema - payment callback/verify/settle
behavior - provider error semantics - identifiers from examples as
production constants

When ground truth is absent, mark the capability:
`BLOCKED BY GROUND TRUTH`

Do not implement a plausible guess.

Provider priority: 1. real provider/API output 2. official
Swagger/OpenAPI/vendor documentation 3. accepted project ADR / confirmed
business rule 4. explicit owner-confirmed example 5. verified
implementation evidence 6. general engineering knowledge only for
explanation/design, never to invent financial/provider truth

## 3. Financial precision and units

-   Never use binary float for money, weights, prices, quantities or
    commissions.
-   Use exact Decimal / fixed precision / decimal strings at API
    boundaries as appropriate.
-   Kimia uses **rial** while the platform customer display uses
    **toman**.
-   Rial↔Toman conversion occurs centrally in the backend only.
-   Frontend never performs financial conversion.
-   Balances may be positive, zero or negative.
-   Coin and Currency are dynamic catalogs sourced from Kimia; never
    hard-code sample IDs.
-   Confirmed 18k equivalence formula: `(weight × fineness) / 750`.
-   A known generic price-formula shape is `price = (api / x) * y + z`,
    but x/y/z, precedence, rounding, freshness and provider rules are
    NOT to be guessed. Keep runtime pricing blocked until explicitly
    grounded.

## 4. Multi-tenancy / white label

Every tenant is isolated.

Tenant resolution for customer/backoffice requests is server-side,
preferably from a verified Host/domain binding. **Do not accept
client-supplied `tenant_id` as authority.**

Unknown, inactive or unverified hosts fail closed.

All tenant-owned data access must be tenant-scoped, including: -
users/customers - staff - permissions/roles where applicable -
orders/quotes - custody - delivery - settings - integrations/secrets -
bank accounts - audit - idempotency - outbox/events - operational views

Add adversarial cross-tenant tests.

Branding is runtime tenant configuration: logo, palette/theme, legal
copy, locale/direction, domains and contact/support configuration. Do
not bake the pilot brand into the core.

## 5. Identity and access

### Customer

Default confirmed direction: **mobile + OTP only**. No customer password
login.

Existing verified customer: `mobile -> OTP -> authenticated session`

New customer:
`mobile -> registration -> first/last name + national code + optional referrer + legal acceptance -> identity verification -> registration policy -> activation`

Identity verification, admin approval and runtime access are separate
concepts.

Customer Access Status is separate from Customer Level: - active -
limited - suspended - blocked

Runtime restrictions must be explicit (e.g. deny login vs deny trading),
auditable and tenant-scoped.

### Staff

Tenant Owner / Admin / Operator use username + password. - random
tenant-specific bootstrap credential - never universal `admin/admin` -
mandatory password change on first login - tenant/host resolved - fail
closed cross-tenant - least privilege - owner/admin/operator authority
is not interchangeable

Use a mature permission system and keep permissions explicit and
testable.

### Referral

Mobile may be used as a user-friendly lookup key within the same tenant,
but persist stable user relation (`referrer_user_id`), not a fragile
mobile string. Public referral links should use non-sensitive opaque
codes, not raw mobile numbers.

## 6. Customer levels / trading policy

Customer Level/Group is a **Talamala business concept** and MUST NOT be
confused with Kimia AccountType/Group.

Policy may eventually control: - whether sufficient balance/credit is
required - commission/markup adjustments - min/max order sizes - trading
restrictions - anti-scalping lock windows - special/VIP behavior

Do not invent numeric values. Store policy data explicitly and
version/trace it where financially relevant.

## 7. Onboarding policy modes

Design configuration for: 1. Manual Approval 2. Assisted Automation 3.
Full Automation

But fail closed: - if Jibit/Kimia create-customer ground truth or
credentials are unavailable, automatic modes cannot be activated. -
Kimia customer creation must not be implemented from guesswork.

## 8. Quote → Order → Settlement algorithm

Target architecture:

`Policy/Gates` → `Fresh Price Observation` →
`Backend Unit Normalization` → `Product Formula` →
`Customer Level / Side Adjustment` → `Quantity/Subtotal` →
`Commission/Tax` → `Final Rounding` → `Immutable Quote` →
`Server-owned Order` → `Idempotent external write` → `Kimia readback` →
`Settlement/Reconciliation` →
`Completed only when authoritative conditions are satisfied`

Rules: - Quote snapshot is immutable. - Quote expiration is backend
UTC. - expired quote cannot execute. - edit/reprice creates a new
Quote. - client must never submit authoritative `gold_price`,
commission, balance, Weight750 result or final total. - financial
mutations require idempotency, audit and trace IDs. - Read and Write
clients/policies are separate. - Retry policy for reads and writes is
different. - after successful Kimia write, re-read authoritative state
and reconcile. - no ledger-only completion.

Exact freeze duration, pricing provider, x/y/z, rounding, commission,
tax, hold and settlement semantics remain blocked until grounded.

## 9. Kimia boundary

Create an Anti-Corruption Layer between Talamala domain and Kimia.

Recommended conceptual components: - KimiaReadClient -
KimiaWriteClient - KimiaCredentialResolver - AccountRepository /
CatalogRepository / VoucherRepository - CustomerKimiaBinding -
KimiaMapper - KimiaReadbackVerifier - ReconciliationService -
provider-specific DTOs isolated from core domain

Controllers must never call Kimia HTTP client directly.

Known read evidence and known endpoint inventory are in the attached
Kimia documents. Treat any write payload not explicitly proven there as
UNKNOWN.

## 10. Custody / Amanat

Custody is physical inventory entrusted to the business and is platform
truth.

Model separately from financial wallet/balance.

Expected lifecycle must support business-confirmed physical types such
as coins, 24k bars, standard melted gold and extensible other physical
assets, but exact product catalog/status transitions must be confirmed
before locking schema.

Every custody mutation: - tenant scoped - actor attributed - auditable -
reasoned - idempotent where request replay is possible - independent of
Kimia financial balance unless an explicit settlement workflow bridges
them

## 11. External integrations

All provider credentials: - encrypted at rest - tenant scoped when
tenant-specific - never returned to frontend - never logged - never
committed - rotatable - health/preflight tested without leaking secrets

### Jibit

Use attached official v1.5.2 documentation as vendor evidence. Implement
token lifecycle, matching/identity flows and provider errors only
according to official contract. Live readiness requires real
sandbox/production evidence.

### SMS.ir

Use attached/derived SMS.ir evidence. OTP provider must be abstracted
behind a backend interface. Tenant templates/credentials, provider
errors, delivery receipts and production delivery need explicit
evidence.

### Payment

Do NOT implement a bank gateway from memory. For BehPardakht Mellat or
any bank gateway, obtain current official merchant contract first,
including amount unit, request, callback trust, verify, settle,
inquiry/reversal, retry/idempotency and result codes. Until then:
`BLOCKED BY GROUND TRUTH`.

### Goftino

Do not invent widget/API/privacy behavior. Obtain official current
integration and privacy/PII contract, then implement tenant-configured
support placement.

### Price provider

Do not implement until official provider and response/freshness/failover
contract are supplied.

## 12. API and OpenAPI

API-first/contract-driven development.

Maintain separate canonical contracts where useful: - public/customer
API - backoffice/admin/operator API - authentication API

Every production route must have: - request schema - response schema -
errors - auth requirements - permission - tenant behavior - pagination
contract where applicable - idempotency requirement where applicable -
examples that are explicitly non-authoritative

OpenAPI must match runtime. Add contract tests to detect drift.

Never put `tenant_id` into client contracts as an authority when tenant
is Host-resolved.

## 13. Frontend architecture

Build distinct customer and backoffice experiences while sharing design
tokens/components where sensible.

Requirements: - Persian-first - RTL - mobile-first - responsive from
small phone through desktop - PWA-safe on iPhone, Android, Windows and
macOS browsers - accessible keyboard/focus/contrast semantics -
loading/empty/error/forbidden/offline states - no internal accounting
jargon exposed to customers - no independent financial calculations - no
secrets - no sensitive identifiers unnecessarily exposed -
server-provided formatted/normalized financial data

Customer journeys: - OTP/login - registration/Jibit states - dashboard -
authoritative assets - market/product discovery - quote - order
confirmation/history/detail - custody - delivery request/status -
profile/security/activity - support

Backoffice journeys: - login/password rotation - operational dashboard -
registration review - customer detail/access/level -
orders/settlement/reconciliation queues - custody/delivery operations -
audit logs - outbox/operations - tenant bank/integration/domain/branding
settings - staff/role/permission management

Before broad UI implementation, produce one real high-fidelity page
using the actual design system and get owner approval. Do not copy
competitor identity/layout/text.

Theme settings should support multiple curated palettes and a
compact/dropdown selection UX rather than an excessively long settings
page.

## 14. Suggested repository tree

    talamala/
    ├── README.md
    ├── AGENTS.md
    ├── docs/
    │   ├── 00-master/
    │   ├── adr/
    │   ├── architecture/
    │   ├── domain/
    │   ├── api/
    │   ├── providers/
    │   ├── ux/
    │   ├── operations/
    │   ├── security/
    │   └── traceability/
    ├── backend/
    │   ├── app/
    │   │   ├── Domain/
    │   │   ├── Application/
    │   │   ├── Integrations/
    │   │   ├── Infrastructure/
    │   │   └── Http/
    │   ├── database/
    │   ├── routes/
    │   └── tests/
    ├── frontend/
    │   ├── customer/
    │   ├── backoffice/
    │   └── shared/
    ├── openapi/
    │   ├── auth-v1.openapi.yaml
    │   ├── customer-v1.openapi.yaml
    │   └── backoffice-v1.openapi.yaml
    ├── infra/
    │   ├── containers/
    │   ├── deploy/
    │   ├── monitoring/
    │   └── backup/
    ├── scripts/
    └── .github/workflows/

This is a target logical tree, not permission to prematurely generate
every folder/class. Create only what the current stage needs.

## 15. Delivery algorithm / development method

Mandatory lifecycle:

`Preserve → Inspect → Inventory → Extract → Compare → Validate → Classify → Document → Integrate → Continue`

For greenfield Talamala, "Preserve/Inspect" means preserve and inspect
the supplied truth packet before implementation.

Before every feature: 1. inspect current GitHub branch/base/head and
open/merged/closed PRs 2. inspect existing code/docs/OpenAPI/tests 3.
search for duplicate capability 4. identify source/ground truth 5.
write/update requirement and acceptance criteria 6. classify unknowns 7.
design architecture and API contract 8. implement smallest vertical
slice 9. tests 10. OpenAPI/contract verification 11. exact-SHA CI 12.
documentation and traceability 13. only then continue

No silent architectural, financial, migration, permission, API or UX
changes.

## 16. Capability statuses

Use only explicit statuses: - REUSE AS-IS - REUSE AFTER FIX - REFACTOR -
REBUILD - IMPLEMENTED --- NOT TESTED - TESTED --- NOT MERGED - MERGED
--- CLOSURE PENDING - BLOCKED BY GROUND TRUTH - DUPLICATE CANDIDATE -
SUPERSEDED - HISTORICAL ONLY - NOT IMPLEMENTED

Test statuses: - WRITTEN --- NOT EXECUTED - EXECUTED --- PASS - EXECUTED
--- FAIL - NOT APPLICABLE

Never say Production Ready without green release gates on the exact
candidate SHA.

## 17. Traceability

For every capability maintain:

`Requirement → Source → Ground Truth → Architecture → Database → Backend → API → OpenAPI → Frontend → Permission → Audit → Idempotency → Tests → CI exact SHA → PR → Merge → Visual Verification → Documentation`

Create a machine-readable capability ledger early.

## 18. Security baseline

-   deny by default
-   host-based tenant isolation
-   least privilege
-   CSRF/session protections appropriate to architecture
-   rate-limit OTP/auth/sensitive operations
-   hashed OTP or short-lived secure verification state
-   secret encryption and masking
-   no secrets in logs/docs/Git/UI
-   audit actor/tenant/action/reason/target/correlation
-   idempotency for sensitive mutations
-   dependency audit
-   SAST/secret scanning
-   adversarial tenant tests
-   callback authenticity for external providers only according to
    official contract
-   backup/restore and migration rehearsal before release

## 19. CI/CD baseline

At minimum establish gates for: - backend unit/feature/integration
tests - database fresh migration - frontend typecheck/build/tests -
OpenAPI validation and runtime contract tests - lint/static analysis -
dependency vulnerability audit - secret scan - tenant/security tests -
PWA/browser smoke - production configuration validation - migration
rollout/rollback rehearsal when release candidate - backup/restore drill
before production - exact-SHA release report

Old/sibling SHA results never prove the current SHA.

## 20. Roadmap

### Stage 0 --- Truth packet & repository governance

No product code. - read every supplied document - create source
register - create unknown/ground-truth register - create capability
ledger - create ADR index - define branching/PR/CI policy Exit: every
known rule has source/classification.

### Stage 1 --- Architecture skeleton

-   backend/frontend/OpenAPI/CI skeleton
-   tenant resolution
-   configuration/secrets boundary
-   base audit/idempotency
-   health checks Exit: architecture tests and exact-SHA CI green.

### Stage 2 --- Identity vertical

-   customer OTP
-   staff auth/password rotation
-   tenant/session isolation
-   onboarding state model
-   Jibit adapter according to official contract Exit: authenticated E2E
    with provider fake/contract evidence; live status clearly separate.

### Stage 3 --- Kimia read vertical

-   immutable Customer↔Kimia binding
-   accounts/catalog/balance/transactions reads
-   snapshots only as rebuildable derived data
-   rial→toman backend normalization Exit: customer financial view comes
    only from Kimia-derived authoritative read.

### Stage 4 --- Customer/admin UX foundation

-   approved high-fidelity page
-   design system
-   responsive/PWA/accessibility
-   dashboard/assets/onboarding/admin review Exit: real browser/device
    acceptance.

### Stage 5 --- Pricing & Quote

BLOCK until provider/formula/freshness/rounding truth exists. Then
implement backend-owned immutable Quote.

### Stage 6 --- Order & Kimia write

BLOCK until exact Kimia write contracts are proven. Then: Quote → Order
→ idempotent Kimia write → readback → reconcile.

### Stage 7 --- Settlement/Reconciliation

Implement only from confirmed semantics; no ledger-only completion.

### Stage 8 --- Custody/Delivery

Physical platform-truth vertical, audited and tenant scoped.

### Stage 9 --- Payments

BLOCK until official gateway contract and sandbox evidence. Implement
request/callback/verify/settle/inquiry/reversal exactly as contract
requires.

### Stage 10 --- White-label operations

Branding/domains/integrations/bank
accounts/staff/audit/outbox/observability.

### Stage 11 --- Pilot closure

-   complete OpenAPI
-   authenticated E2E
-   provider sandbox/live controlled smoke
-   exact-SHA full CI
-   visual owner approval
-   migration rehearsal
-   backup/restore
-   rollback plan

### Stage 12 --- Production closure

-   DNS/TLS
-   secret rotation
-   monitoring/alerts/SLO
-   worker/scheduler operations
-   incident/runbooks
-   production smoke and rollback
-   release evidence bundle

## 21. First instruction after receiving this packet

Do NOT write application code immediately.

First return: 1. a concise statement of what you understand Talamala to
be; 2. a Source Register separating CONFIRMED / PARTIAL / UNKNOWN; 3. a
Ground Truth Blocker Register; 4. proposed ADR list; 5.
capability/domain inventory; 6. proposed repository skeleton; 7.
proposed Stage 0--3 plan with exit criteria; 8. contradictions or
decisions that genuinely require owner input.

Then stop for owner decisions only where genuinely necessary. For all
safe independent documentation/governance work, proceed without asking
repetitive questions.

## 22. Communication with owner

Speak Persian, clear and practical. Start with result/status, then short
explanation. Owner is business-domain expert, not expected to operate as
a professional programmer. Never ask the owner to remember rules already
supplied in this packet. If owner must run a command, give exactly one
command at a time and wait for result. Do not drag owner into
Windows/WSL/Docker repair unless explicitly requested.

## 23. Final warning

A clean greenfield repository is not permission to invent business
truth.

Talamala must be simpler in structure than its predecessor, but stricter
in truth: - no duplicate financial balance - no guessed Kimia behavior -
no client financial authority - no cross-tenant leakage - no
undocumented sensitive change - no "complete" without traceability and
exact-SHA evidence.

# TALAMALA --- ONE-SHOT HANDOFF OVERRIDE

This packet is intended to be sufficient as the **single initial
handoff**. The owner should not have to re-teach architecture, project
method, known business rules, known provider evidence, or the list of
unresolved external facts.

## Your first responsibility

Before asking the owner anything: 1. Read **every file in this packet**,
including preserved source evidence. 2. Inspect the new Talamala GitHub
repository completely. 3. Build `SOURCE_REGISTER`, `DECISION_REGISTER`,
`GROUND_TRUTH_REGISTER`, `CAPABILITY_LEDGER`, `ADR_INDEX`, and
`TRACEABILITY_LEDGER`. 4. Resolve anything resolvable from these
artifacts, GitHub, official vendor documentation, sandbox APIs, and
current provider contracts **yourself**. 5. Ask the owner only for a
genuine business decision, credential/authorization, or external fact
that cannot be obtained safely elsewhere.

Do not ask the owner to repeat any rule already contained here.

## Greenfield rule

GoldPlatform code is historical evidence, not Talamala source code. Do
not copy old implementation wholesale. You may study historical
artifacts to learn requirements, mistakes, edge cases, test ideas and
provider evidence. Build clean Talamala code.

## Automatic evidence acquisition

When an official artifact is named but not physically bundled (for
example the current raw Kimia Swagger, current payment merchant
contract, current Goftino contract, or current price-provider contract),
you must: - first attempt to retrieve it from the authoritative
connected source or official vendor; - archive it with
date/hash/version; - compare it against this packet; - stop only the
affected capability if still unavailable. Do **not** stop the entire
project and do **not** ask the owner to re-explain the API.

## Historical vs normative

Files under `evidence/historical/` explain how knowledge was discovered.
They are not permission to inherit old technical debt. Files under
`spec/` are the greenfield normative design. Files under
`provider-evidence/` are provider evidence; official/current raw
contracts outrank summaries.

## Non-negotiable completion rule

Never call a capability complete from code alone. Completion requires
its applicable chain: Requirement → Source → Ground Truth → ADR → DB →
Backend → API → OpenAPI → Frontend → Permission → Audit → Idempotency →
Tests → exact-SHA CI → PR → Merge → Visual/Runtime Verification → Docs.
