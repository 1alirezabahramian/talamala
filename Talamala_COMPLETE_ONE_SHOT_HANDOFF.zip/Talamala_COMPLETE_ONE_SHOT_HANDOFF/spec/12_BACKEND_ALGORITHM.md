# Backend Execution Algorithms

## Request boundary

Host → resolve tenant → authenticate → authorize → validate → load
policy → execute application service → audit/result.

## Customer onboarding

Mobile → OTP → existing/new decision → registration data → Jibit match →
registration policy → (manual/assisted/automatic) → Kimia binding/create
only when grounded → access status → session.

## Financial read

Authenticated customer → tenant → canonical Kimia binding → Kimia Read
Client → exact decimal normalization → rial→toman backend presentation →
response. Cache may assist but Kimia wins conflicts.

## Trade

Access/policy gates → authoritative fresh price → backend formula →
immutable Quote → customer confirms Quote ID → server validates
unexpired/unchanged → creates Order → idempotent provider write → Kimia
readback → settlement/reconciliation → terminal state.

## Physical custody

Customer/staff intent → permission/tenant → physical custody aggregate →
movement/transition → audit → notification. Custody is never a financial
wallet.

## External mutation safety

Request correlation + idempotency key + sanitized audit intent →
provider write using operation-specific retry semantics → capture
provider result → readback/verification → reconcile → expose safe
outcome.
