# Talamala Domain Rules --- Confirmed / Blocked

## Confirmed

-   Kimia final truth: Money/Gold/Coin/Currency.
-   Platform final truth: physical Custody/Amanat.
-   Balances may be positive/zero/negative.
-   Coin/Currency dynamic.
-   no float.
-   Kimia rial; platform customer display toman; backend conversion.
-   18k equivalence: (weight × fineness) / 750.
-   Customer Level is separate from Kimia Group.
-   Customer access state is separate from onboarding and level.
-   Customer auth direction: OTP-only.
-   Staff auth: username/password; first-login rotation.
-   Host-resolved tenant; no client-authoritative tenant_id.
-   Quote is immutable; edit/reprice means new quote.
-   Read and Write integration behavior separated.
-   Post-write readback/reconciliation is mandatory for Kimia financial
    mutation.

## Known business-side mapping evidence

Customer buys gold → Kimia business side Sell. Customer sells gold →
Kimia business side Buy.

Historical/verified project evidence reports operational/form codes 4/3
and Swagger trade actions 64/32 for paper-gold testing. Treat the
attached Project Memory/Kimia Audit as evidence and revalidate against
the actual official Swagger/current runtime before implementing
greenfield write paths.

## Blocked until ground truth

-   Kimia Create Customer exact payload and duplicate semantics
-   Kimia financial write payloads beyond proven operation-specific
    evidence
-   coin/currency write mapping
-   price provider/freshness
-   x/y/z and rounding precedence
-   commissions/taxes numeric policy
-   credit/hold/freeze/settlement rules
-   payment gateway contract
-   Goftino contract
