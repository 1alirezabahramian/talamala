# API & OpenAPI Contract Policy

OpenAPI is executable product contract, not decorative documentation.

Maintain: - openapi/auth-v1.openapi.yaml -
openapi/customer-v1.openapi.yaml - openapi/backoffice-v1.openapi.yaml

Every endpoint must document: method/path, purpose, auth, permission,
tenant resolution, request, response, errors, pagination, idempotency,
examples.

Contract tests must fail on runtime/OpenAPI drift.

Backoffice must never trust client-provided tenant_id when tenant is
Host-resolved.

Recommended route families (names are design targets, not pre-approved
exact contracts): - /v1/public/* - /v1/auth/* - /v1/customer/* -
/v1/admin/* - /v1/operator/* - /v1/owner/* - /v1/ops/\*

Do not finalize route names until Stage 0/1 API ADR is accepted.
