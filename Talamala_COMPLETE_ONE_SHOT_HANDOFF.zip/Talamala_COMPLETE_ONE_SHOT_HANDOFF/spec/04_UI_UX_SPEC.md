# UI/UX Product Specification

## Principles

-   Persian, RTL, mobile-first.
-   Professional financial UX without exposing internal accounting
    jargon.
-   Customer sees outcomes, statuses, authoritative values and clear
    next actions.
-   Backend owns financial calculations.
-   Every screen supports loading, empty, error, forbidden and retry
    states.
-   Responsive: iPhone/Android phones, tablets, desktop browsers;
    PWA-safe for iOS/Android/Windows/macOS.
-   Accessibility: semantic HTML, keyboard navigation, focus, contrast,
    scalable typography.

## Customer information architecture

Login/OTP → Registration → Verification status → Dashboard → Assets →
Market → Quote → Confirm Order → Orders → Custody → Delivery →
Profile/Activity → Support.

## Backoffice information architecture

Staff Login → Password Rotation → Dashboard → Registration Queue →
Customers → Orders → Settlement/Reconciliation → Custody → Delivery →
Staff/Permissions → Bank/Integrations → Branding/Domains → Audit →
Outbox/Ops.

## Design-system rule

Before broad page production, create one real high-fidelity page and
obtain owner approval. Then extract tokens/components. Do not copy
competitors.

## White-label theme

Support curated palettes and tenant branding. Palette selection should
be compact (e.g. dropdown/popover) rather than making settings pages
excessively long.
