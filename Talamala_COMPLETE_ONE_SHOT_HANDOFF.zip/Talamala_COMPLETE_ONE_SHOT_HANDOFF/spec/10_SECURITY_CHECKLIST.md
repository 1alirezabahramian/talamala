# Security & Tenant Isolation Checklist

-   [ ] tenant derived server-side from verified host/domain
-   [ ] unknown/inactive/unverified host fails closed
-   [ ] every tenant-owned query tenant-scoped
-   [ ] route model binding cannot cross tenant
-   [ ] staff first-login password rotation enforced
-   [ ] customer OTP rate limiting and secure verification state
-   [ ] secrets encrypted/masked/not logged
-   [ ] provider credentials never serialized to client
-   [ ] sensitive mutations permission checked
-   [ ] audit actor + tenant + target + reason + correlation
-   [ ] idempotency tenant scoped
-   [ ] cross-tenant adversarial tests
-   [ ] dependency/security audit exact SHA
-   [ ] secret scan
-   [ ] callback authenticity follows official provider contract
-   [ ] backup/restore drill before production
