# Proposed Repository Tree

``` text
talamala/
├── README.md
├── AGENTS.md
├── docs/
│   ├── 00-master/
│   ├── architecture/
│   ├── domain/
│   ├── adr/
│   ├── api/
│   ├── providers/
│   ├── ux/
│   ├── security/
│   ├── operations/
│   └── traceability/
├── backend/
│   ├── app/
│   │   ├── Domain/
│   │   ├── Application/
│   │   ├── Integrations/
│   │   ├── Infrastructure/
│   │   └── Http/
│   ├── database/
│   ├── routes/
│   └── tests/
├── frontend/
│   ├── customer/
│   ├── backoffice/
│   └── shared/
├── openapi/
│   ├── auth-v1.openapi.yaml
│   ├── customer-v1.openapi.yaml
│   └── backoffice-v1.openapi.yaml
├── infra/
│   ├── containers/
│   ├── deploy/
│   ├── monitoring/
│   └── backup/
├── scripts/
└── .github/workflows/
```

This is a logical target. Avoid generating empty architecture theatre.
