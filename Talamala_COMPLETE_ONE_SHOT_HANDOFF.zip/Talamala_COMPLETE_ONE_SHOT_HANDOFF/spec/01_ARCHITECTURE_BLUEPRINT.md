# Talamala Architecture Blueprint

## Bounded contexts

1.  Tenant & White-label
2.  Identity & Access
3.  Customer Onboarding
4.  Customer Policy / Level / Access
5.  Kimia Integration
6.  Financial Read Model
7.  Market & Pricing
8.  Quote
9.  Order
10. Settlement & Reconciliation
11. Physical Custody
12. Delivery
13. Payments
14. Notifications
15. Support
16. Audit / Idempotency / Outbox
17. Operations / Observability

## Dependency direction

Domain must not depend on HTTP/vendor DTOs. Provider adapters depend
inward on application/domain contracts.

## Truth boundaries

  Domain                    Final truth
  ------------------------- --------------------
  Money                     Kimia
  Gold                      Kimia
  Coin                      Kimia
  Currency                  Kimia
  Physical Custody/Amanat   Talamala
  Quote snapshot            Talamala
  Order lifecycle           Talamala
  Audit/Intent/Result       Talamala
  Final financial balance   Never local ledger

## Backend invariants

-   Controllers do not call Kimia directly.
-   Financial values use Decimal.
-   Rial→Toman only backend.
-   Client cannot choose tenant authority.
-   Client cannot set authoritative price/commission/balance.
-   Every sensitive mutation: permission + tenant + idempotency +
    audit + correlation.
-   External write success requires readback/reconciliation where
    provider semantics require it.
