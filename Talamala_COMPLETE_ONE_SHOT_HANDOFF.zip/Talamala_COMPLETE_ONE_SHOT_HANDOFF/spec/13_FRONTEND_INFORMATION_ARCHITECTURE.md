# Frontend IA and UX Acceptance

## Customer

OTP/Login; Registration; Verification; Dashboard; Assets; Market; Quote;
Order Confirm; Orders; Custody; Delivery; Profile; Activity; Support.

## Backoffice

Login; Password Rotation; Dashboard; Registration Queue; Customers;
Access/Level; Orders; Settlement/Reconciliation; Custody; Delivery;
Staff/RBAC; Bank Accounts; Integrations; Domains/Branding; Audit;
Outbox/Ops.

## UX gates

-   Persian RTL, mobile-first.
-   No financial calculation in browser.
-   Server owns price/commission/normalization.
-   Responsive phone/tablet/desktop.
-   PWA install/use-safe on iOS/Android/Windows/macOS.
-   Accessible keyboard/focus/contrast.
-   loading/empty/error/forbidden/offline/retry states.
-   one real high-fidelity page approved before broad UI production.
-   curated theme palettes; compact selector.
