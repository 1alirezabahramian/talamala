# Talamala Roadmap & Exit Criteria

0.  Truth/Governance --- source register, blockers, ADR plan, capability
    ledger. **No code.**
1.  Foundation --- tenant, secrets, audit, idempotency, CI.
2.  Identity --- customer OTP + staff auth + Jibit boundary.
3.  Kimia Read --- binding/catalog/balance/transactions.
4.  UX foundation --- approved high-fidelity customer + backoffice
    patterns.
5.  Pricing/Quote --- only after ground truth.
6.  Order/Kimia Write --- only after exact write truth.
7.  Settlement/Reconciliation.
8.  Custody/Delivery.
9.  Payment --- only official contract + sandbox.
10. White-label/Ops.
11. Pilot closure.
12. Production closure.

Every stage exits only with traceability, tests, OpenAPI where
applicable, exact-SHA CI and documentation.
