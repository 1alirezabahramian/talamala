# Data Model Blueprint --- conceptual, not permission to invent financial truth

Core aggregates/tables should be designed around: - tenants,
tenant_domains, tenant_branding/settings - users/customers, staff
identities, roles/permissions - customer_access_transitions,
customer_levels/policies - customer_kimia_bindings (stable immutable
external identity relation) - provider_connections / encrypted tenant
integration settings - derived Kimia catalog/snapshot tables with
source/synced_at/rebuild semantics - quotes + immutable quote
snapshots - orders + order lifecycle transitions -
settlement/reconciliation cases - custody_items / custody_movements -
delivery_requests / delivery transitions - payment_attempts (only after
official gateway contract) - notifications - audit_logs -
idempotency_registry - outbox_events

Do NOT create a local competing balance table for
Money/Gold/Coin/Currency. If a cache/projection exists, its
naming/schema must make `derived_from_kimia`, source timestamp and
rebuildability explicit. All tenant-owned rows carry/enforce tenant
scope unless the table is genuinely platform-global. Financial Decimal
precision is decided explicitly by ADR after provider/schema evidence;
never float.
