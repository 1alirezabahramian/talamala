# Talamala --- Complete One-Shot Handoff Pack

این بسته برای تحویل پروژه جدید **Talamala** به یک AI/اکانت/تیم جدید
طراحی شده است، بدون دادن کد GoldPlatform و بدون نیاز به آموزش دوباره
اصول پروژه.

ترتیب مطالعه اجباری: 1. `00_START_HERE_MASTER_PROMPT.md` 2. همه فایل‌های
`spec/` 3. `management/` 4. `provider-evidence/` 5.
`evidence/historical/`

این بسته Secret/Credential واقعی ندارد. Secret باید فقط از Secret
Store/Environment امن دریافت شود.

اگر یک قرارداد خارجی در بسته کامل نیست، عامل جدید موظف است خودش از منبع
رسمی آن را بازیابی کند و فقط همان Capability را تا زمان Ground Truth قفل
کند؛ نباید از مالک بخواهد قواعد موجود در این بسته را دوباره توضیح دهد.
