# Jibit Usage Policy

The official Persian Identicator Project v1.5.2 PDF is bundled under
`provider-evidence/official/`.

Treat that PDF as vendor contract evidence for supported token/matching
paths and payloads. Before production, verify current vendor version,
sandbox/live credentials, token cache/refresh behavior, rate limits,
errors and controlled live onboarding. Jibit verification is NOT
equivalent to admin approval or runtime customer access.
