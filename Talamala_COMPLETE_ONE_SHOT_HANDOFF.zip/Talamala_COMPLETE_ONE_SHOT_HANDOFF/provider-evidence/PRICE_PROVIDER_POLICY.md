# External Price Provider

No provider/formula may be invented. Before Pricing runtime, archive
official provider contract and owner-approved business pricing policy:
response fields, units, timestamp, freshness, market state,
authentication, failure/failover, x/y/z coefficients, side adjustments,
commission/tax, rounding order and Quote expiry. Until grounded:
`BLOCKED BY GROUND TRUTH`.
