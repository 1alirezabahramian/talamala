# External Provider Register

  ---------------------------------------------------------------------------------
  Provider          Purpose                Current evidence in Greenfield status
                                           this packet         
  ----------------- ---------------------- ------------------- --------------------
  Kimia             financial/accounting   Project Memory +    Read: partially
                    truth                  Kimia audit;        grounded; Write:
                                           official Swagger    operation-specific
                                           itself is NOT       ground truth
                                           included unless     required
                                           separately supplied 

  Jibit             identity/inquiry       Official v1.5.2 PDF Contract evidence
                                           included            available; live
                                                               readiness not proven

  SMS.ir            OTP/SMS                derived/reference   integration design
                                           notes included;     allowed; tenant/live
                                           source library      proof required
                                           evidence exists     

  BehPardakht       payment                no current official BLOCKED BY GROUND
  Mellat                                   merchant contract   TRUTH
                                           in packet           

  Goftino           support/chat           no official current BLOCKED BY GROUND
                                           contract in packet  TRUTH

  Price provider    market prices          no official current BLOCKED BY GROUND
                                           provider contract   TRUTH
  ---------------------------------------------------------------------------------

## Important

Do not convert "we know the vendor name" into "we know the API". Missing
official contracts must be requested and added to
`docs/providers/official/` before implementation.
