# Payment Gateways

Architecture must support pluggable payment providers, but no
bank-specific runtime may be invented.

Known intended provider evidence includes BehPardakht Mellat, but the
current official merchant contract is not bundled. The implementing
agent must independently obtain/archive the official current merchant
documentation and sandbox contract before coding: amount unit,
credentials, request/token/redirect, callback trust, verify, settle,
inquiry, reversal, retry/idempotency, result codes.

Until then: `BLOCKED BY GROUND TRUTH`. Do not ask the owner to explain
standard gateway mechanics; retrieve the official contract first.
