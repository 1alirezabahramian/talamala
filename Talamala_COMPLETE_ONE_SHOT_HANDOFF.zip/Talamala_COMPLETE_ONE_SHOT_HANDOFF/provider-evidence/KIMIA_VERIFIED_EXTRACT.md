# Kimia --- Verified/Preserved Evidence Extract

## Raw contract location

Historical GoldPlatform repository contains `swagger.json`, OpenAPI
3.0.4, title `Kimia API`, version v1, server evidence
`http://94.101.184.26:11000`.

The new Talamala agent MUST fetch the raw current Swagger from the
authoritative source and archive it. This extract is not a replacement
for raw Swagger.

## Endpoint inventory preserved from repository Swagger evidence

-   GET/POST/PUT `/api/account`
-   GET `/api/account/groups`
-   GET `/api/barcode`
-   GET `/api/barcode/exists/{id}`
-   GET `/api/images/{hash}`
-   GET `/api/product`
-   GET `/api/product/coins`
-   GET `/api/product/currencies`
-   GET `/api/report/dealsbalance`
-   GET `/api/rfid`
-   GET `/api/rfid/inventory`
-   GET `/api/voucher/balance/{id}`
-   GET `/api/voucher/balances`
-   GET `/api/voucher/transactions/{id}`
-   POST `/api/voucher/adjustment`
-   POST `/api/voucher/exchangecurrency`
-   POST `/api/voucher/exchangegold`
-   POST `/api/voucher/exchangemoney`
-   POST `/api/voucher/tradebarcode`
-   POST `/api/voucher/tradecash`
-   POST `/api/voucher/tradecurrency`
-   POST `/api/voucher/transfergold`
-   POST `/api/voucher/transfermoney`
-   DELETE `/api/voucher/deleterecord`
-   wallet endpoints
-   GET/HEAD `/healthz`

## Account types preserved from Swagger

1 bankdari; 3 retail; 5 capital/withdrawal; 6 bank; 8 internal; 9 melt;
10 amanat; 11 expense; 12 employees.

## Important schema evidence

Balance/transaction evidence includes AccountId, Weight, Money,
CurrencyId and transaction fields such as Action, ProductId, Weight,
Fineness, UnitPrice, GoldPrice, Quantity, Weight750, SumMoney. Write
request evidence includes UUID `RequestId` on relevant requests for
duplicate protection.

## Runtime/business evidence

-   Money/Gold/Coin/Currency final balance truth = Kimia.
-   Coin/Currency catalogs dynamic.
-   Paper-gold historical runtime evidence: operational/form code 3/4
    and Swagger API Action 32/64 on controlled test account evidence.
-   Coin/currency payload mapping remains unverified unless a current
    raw request/response proves it.
-   Physical receive/pay endpoint-specific semantics require current
    confirmation.
-   After every successful financial write, read back from Kimia and
    reconcile.

Never infer an operation from a code name alone.
