# Goftino

Support/chat is an optional tenant-configured integration. Before
implementation, independently retrieve and archive current official
Goftino widget/API/privacy documentation. Verify: site/widget
identifier, secret/auth model, CSP/domain behavior, PII sent,
consent/privacy, PWA/mobile behavior and placement. Until grounded:
`BLOCKED BY GROUND TRUTH`.
