# SMS.ir Contract Extract --- preserved project evidence

Evidence available in the project library states: - RESTful service. -
Authentication header: `X-API-KEY`. - Common HTTP statuses include
200/400/401/429/500. - Time values are described as Unix Time / UTC. -
Unified response shape contains status/message/data. - Sandbox uses a
sandbox API key; structures/errors mirror production while data is
simulated and no real SMS/cost is incurred. - Verify endpoint:
`POST https://api.sms.ir/v1/send/verify`. - Verify body: `mobile`,
`templateId`, `parameters[{name,value}]`. - Successful verify response
contains `messageId` and `cost`. - Template parameters are dynamic and
template IDs are managed by the provider panel. - Evidence also covers
bulk/scheduled sending, reports, credit and line-number queries.

Security note: any literal API key appearing in historical
documentation/examples is NOT a Talamala credential and MUST NOT be
copied into code/config/docs. Use secret storage.

Production closure still requires current official docs, tenant-specific
credentials/templates, provider error mapping, delivery evidence and
live controlled test.
