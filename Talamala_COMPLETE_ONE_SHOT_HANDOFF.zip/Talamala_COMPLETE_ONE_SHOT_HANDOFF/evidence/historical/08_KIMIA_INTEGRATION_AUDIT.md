# GoldPlatform — Kimia API Integration Audit

**Document type:** Technical audit and integration reference  
**Project:** GoldPlatform  
**Module:** Kimia Accounting API Integration  
**Status:** Draft based on reviewed Swagger, runtime logs, and current repository structure  
**Last updated:** 2026-07-27

---

## 1. Purpose

This document records the current verified understanding of the Kimia API and how it should be integrated into GoldPlatform.

The document is based on three sources:

1. Kimia Swagger documentation
2. Runtime logs from the Kimia API
3. Current GoldPlatform source structure

This document is an audit and design reference. It does not mean that the current implementation is already complete or correct.

---

## 2. Source-of-truth policy

When sources disagree, use this priority:

1. **Swagger JSON**
2. **Observed runtime logs**
3. **Current GoldPlatform code**
4. **Older Markdown documentation**

Swagger defines the official contract. Runtime logs show actual server behavior. Current project code must be reviewed against both.

---

## 3. Confirmed API modules

The reviewed Swagger exposes the following modules:

- Account
- Barcode
- Home
- Product
- Report
- RFID
- Voucher
- Wallet

---

## 4. Confirmed endpoint map

### 4.1 Account

| Method | Endpoint | Purpose | Status |
|---|---|---|---|
| GET | `/api/account` | Account list and filtered account lookup | Verified |
| POST | `/api/account` | Create account | Verified |
| PUT | `/api/account` | Update account | Verified |
| GET | `/api/account/groups` | Account groups list | Verified |

> `GET /api/account/{id}` has not been confirmed in the reviewed Swagger section and was not observed in the supplied runtime logs. Any implementation using this route must be treated as suspicious until independently verified.

---

### 4.2 Barcode

| Method | Endpoint | Purpose | Status |
|---|---|---|---|
| GET | `/api/barcode` | Barcode list/search | Visible in Swagger |
| GET | `/api/barcode/exists/{id}` | Barcode existence check | Visible in Swagger |

The exact parameters and response schema still require detailed extraction.

---

### 4.3 Product catalog

| Method | Endpoint | Purpose | Status |
|---|---|---|---|
| GET | `/api/product` | Product list | Verified |
| GET | `/api/product/coins` | Coin list | Verified |
| GET | `/api/product/currencies` | Currency list | Verified |

These endpoints accept no parameters.

---

### 4.4 Report

| Method | Endpoint | Purpose | Status |
|---|---|---|---|
| GET | `/api/report/dealsbalance` | Deals balance report | Verified by Swagger and runtime log |

Observed query example:

```text
?range=0&productId=-2
```

Observed response example:

```text
9.878000000000000
```

---

### 4.5 RFID

| Method | Endpoint | Purpose | Status |
|---|---|---|---|
| GET | `/api/rfid` | RFID list/search | Visible in Swagger |
| POST | `/api/rfid/inventory` | RFID inventory operation | Visible in Swagger |

Request and response contracts still require detailed extraction.

---

### 4.6 Voucher

| Method | Endpoint | Purpose | Status |
|---|---|---|---|
| GET | `/api/voucher/balance/{id}` | Account balance | Verified |
| GET | `/api/voucher/balances` | Multiple account balances | Visible in Swagger |
| GET | `/api/voucher/transactions/{id}` | Account transactions | Verified |
| POST | `/api/voucher/adjustment` | Add or subtract balance | Visible in Swagger |
| POST | `/api/voucher/exchangecurrency` | Currency exchange | Visible in Swagger |
| POST | `/api/voucher/exchangegold` | Gold exchange | Visible in Swagger |
| POST | `/api/voucher/tradebarcode` | Barcode trade | Visible in Swagger |
| POST | `/api/voucher/tradecash` | Cash trade | Visible in Swagger |
| POST | `/api/voucher/tradecurrency` | Currency trade | Visible in Swagger |
| POST | `/api/voucher/transfergold` | Gold transfer | Visible in Swagger |
| POST | `/api/voucher/transfermoney` | Money transfer | Verified by runtime log |
| DELETE | `/api/voucher/deleterecord` | Delete voucher record | Visible in Swagger |

Observed transaction query examples:

```text
?descending=true&pageNumber=0&pageSize=20
?descending=true&pageNumber=1&pageSize=20
```

Observed `transfermoney` request body:

```json
{
  "AccountId": 409,
  "AddToExistingDateVoucher": false,
  "Date": null,
  "Comment": "شارژ حساب از سایت",
  "Action": 2,
  "TargetId": 5,
  "Value": 700000000,
  "CurrencyId": null
}
```

Observed response:

```text
75030
```

This likely represents a created record or voucher identifier, but that meaning must be confirmed from Swagger.

---

### 4.7 Wallet

| Method | Endpoint | Purpose | Status |
|---|---|---|---|
| GET | `/api/wallet/list` | Wallet list | Visible in Swagger |
| GET | `/api/wallet/list/{id}` | Wallet list/details by identifier | Visible in Swagger |
| GET | `/api/wallet/payments` | Wallet payments list | Visible in Swagger |
| GET | `/api/wallet/payments/{id}` | Wallet payment details/list by identifier | Visible in Swagger |
| POST | `/api/wallet` | Create wallet | Visible in Swagger |
| DELETE | `/api/wallet` | Delete wallet | Visible in Swagger |
| POST | `/api/wallet/transfer` | Wallet transfer | Visible in Swagger |

Request and response details still require full schema extraction.

---

### 4.8 Health endpoints

| Method | Endpoint | Purpose | Status |
|---|---|---|---|
| GET | `/healthz` | Service health check | Visible in Swagger |
| HEAD | `/healthz` | Service health check | Visible in Swagger |

---

## 5. Runtime log observations

The supplied daily runtime log shows a repeated request pattern approximately every ten minutes:

```text
GET /api/account
GET /api/product
GET /api/product/coins
GET /api/product/currencies
```

This strongly suggests that these four endpoints are used as periodically refreshed master data.

This is an inference from the log pattern, not an explicit Swagger statement.

Other confirmed runtime usage includes:

- Repeated balance checks using `/api/voucher/balance/{id}`
- Paginated transaction retrieval using `/api/voucher/transactions/{id}`
- Money transfer using `/api/voucher/transfermoney`
- Deals balance reporting using `/api/report/dealsbalance`
- Unauthorized access to `/logs` returning HTTP 401

Observed unauthorized response:

```text
هویت شما شناسایی نشد
```

---

## 6. Confirmed schemas

## 6.1 AccountDto

Represents a Kimia account.

| Field | Type | Nullable | Notes |
|---|---|---:|---|
| AccountId | integer | Yes | Account identifier |
| AccountCode | Not fully extracted | — | Requires exact schema extraction |
| Name | string, max 255 | Yes | Full name |
| NationalCode | string, max 20 | Yes | National code |
| ShopName | string, max 255 | Yes | Shop name |
| EconomicCode | string, max 20 | Yes | Economic code |
| Tel | string, max 255 | Yes | Telephone |
| Mobile | string, max 255 | Yes | Mobile |
| PostalCode | string, max 10 | Yes | Postal code |
| Address | string, max 255 | Yes | Address |
| DateBirthday | date-time | Yes | Date of birth |
| Comment | string, max 500 | Yes | Notes |
| Type | integer | Yes | Account type |
| IsVisible | boolean | Yes | Default true |

Account type values:

| Value | Meaning |
|---:|---|
| 1 | بنکداری |
| 3 | تکفروشی |
| 5 | سرمایه و برداشت |
| 6 | بانک |
| 8 | حساب داخلی |
| 9 | ذوب |
| 10 | امانات |
| 11 | هزینه |
| 12 | کارمندان |

Important Swagger constraint:

```json
{
  "additionalProperties": false
}
```

Do not send undocumented extra properties in `AccountDto`.

---

## 6.2 AccountGroupDto

Represents an account group.

| Field | Type | Nullable | Notes |
|---|---|---:|---|
| Id | integer | No explicit nullable flag | Group identifier |
| Name | string, max 255 | Yes | Group name |
| AccountType | integer | Yes | Account type |

`AccountType` uses the same numeric values as `AccountDto.Type`.

Important distinction:

- `/api/account` filtering uses `Type`
- `/api/account/groups` uses `accountType` as the related account type parameter

A current repository method that sends `accountType` to `/api/account` is inconsistent with the reviewed Swagger and should be corrected after final verification.

---

## 6.3 ProductDto

Represents a Kimia product record.

| Field | Type | Nullable | Notes |
|---|---|---:|---|
| ProductId | integer | Yes | Product identifier |
| Name | string, max 255 | Yes | Product name |
| Fineness | decimal | Yes | Fineness |
| Weight | decimal | Yes | Weight |
| Type | integer | Read-only | Product type |
| IsVisible | boolean | Yes | Visibility |

Product type values:

| Value | Meaning |
|---:|---|
| 11 | ساخته |
| 12 | کالا |
| 13 | نیم‌ساخته |

`Type` is read-only and should not be treated as a writable field unless future Swagger evidence says otherwise.

---

## 6.4 Product endpoint responses

### `GET /api/product`

Returns an array of `ProductDto`.

Example:

```json
[
  {
    "ProductId": 0,
    "Name": null,
    "Fineness": 0,
    "Weight": 0,
    "Type": 0,
    "IsVisible": true
  }
]
```

### `GET /api/product/coins`

Returns an array of `CoinDto`.

Example:

```json
[
  {
    "CoinId": 0,
    "Name": null,
    "Fineness": 0,
    "Weight": 0,
    "Type": 0,
    "IsVisible": true
  }
]
```

### `GET /api/product/currencies`

Returns an array of `CurrencyDto`.

Example:

```json
[
  {
    "CurrencyId": 0,
    "Name": null,
    "IsVisible": true
  }
]
```

Products, coins, and currencies are separate API resources with separate DTOs. They must not be modeled as one shared entity merely because they are under the `Product` Swagger section.

---

## 6.5 AdjustmentRequest

Represents an add/subtract accounting request.

| Field | Type | Required | Nullable | Notes |
|---|---|---:|---:|---|
| RequestId | string, max 36 | No | Yes | Unique request identifier |
| AddToExistingDateVoucher | boolean | No | No | Default false |
| AccountId | integer | Yes | No | Account identifier |
| Date | date-time | No | Yes | Date |
| Comment | string, max 500 | No | Yes | Notes |
| Action | integer | Yes | No | Add/subtract action |
| TagId | integer | No | Yes | Tag identifier |
| Money | decimal | No | Yes | Amount |
| CurrencyId | integer | No | Yes | Currency identifier |
| Weight | decimal | No | Yes | Weight in grams |
| Fineness | decimal | No | Yes | Weight fineness |

Action values:

| Value | Meaning |
|---:|---|
| 2 | اضافه |
| 4 | کسر |

`RequestId` is intended to prevent duplicate voucher registration. UUID version 4 is recommended.

GoldPlatform must generate and persist an idempotency identifier for mutation requests where supported.

---

## 6.6 BalanceDto

Represents an account balance.

| Field | Type | Nullable | Notes |
|---|---|---:|---|
| AccountId | integer | No explicit nullable flag | Account identifier |
| AccountName | string, max 255 | Yes | Account name |
| GroupId | integer | No explicit nullable flag | Group identifier |
| Weight | decimal | Yes | Gold weight |
| Money | decimal | Yes | Monetary balance |
| CurrencyId | integer | No explicit nullable flag | Currency identifier |
| CurrencySymbol | string, max 255 | Yes | Read-only currency symbol |
| GoldPeaks | PeakDto[] | Yes | Gold peaks |
| MoneyPeaks | PeakDto[] | Yes | Money peaks |

Balance values may be positive or negative. Their business meaning must not be assumed without explicit Kimia documentation and project business rules.

---

## 6.7 PeakDto

Embedded in `BalanceDto`.

| Field | Type | Nullable | Notes |
|---|---|---:|---|
| Date | date-time | Yes | Peak date |
| Days | integer | Yes | Number of days |
| Value | decimal | Not specified as nullable | Gold weight or monetary value |

---

## 7. Current GoldPlatform code audit

The active account flow identified in the repository is:

```text
KimiaController
    ↓
Repositories/Kimia/AccountRepository
    ↓
App\Services\KimiaService
```

Confirmed current account repository behavior:

```php
$this->kimia->client()->get(...)
```

Current endpoints used:

```text
GET  /api/account
GET  /api/account/{id}
GET  /api/account/groups
POST /api/account
PUT  /api/account
```

Current concerns:

1. `GET /api/account/{id}` is unverified.
2. `all()` reportedly uses `accountType` while Swagger expects `Type`.
3. Error handling returns `[]` or `null`, which may hide API errors.
4. Multiple duplicate Kimia service/client/repository classes exist.
5. No duplicate implementation should be deleted before usage verification.

Known duplicate or overlapping classes include:

```text
App\Services\KimiaService
App\Services\Kimia\KimiaService
App\Clients\KimiaClient
App\Services\Kimia\KimiaClient
App\Repositories\Kimia\AccountRepository
App\Services\Kimia\AccountRepository
App\Services\Kimia\AccountService
App\Services\Kimia\CustomerService
App\Services\Kimia\BaseKimiaService
```

---

## 8. Domain separation recommendation

GoldPlatform should not use one large `KimiaService` for all operations.

Recommended integration domains:

```text
Kimia/
├── Accounts/
├── Catalog/
│   ├── Products/
│   ├── Coins/
│   └── Currencies/
├── Vouchers/
├── Wallets/
├── Trading/
├── Barcodes/
├── RFID/
└── Reports/
```

Recommended responsibility split:

```text
KimiaClient
    HTTP authentication, headers, timeout, request execution

DTOs
    Typed request and response data

Repositories
    Endpoint-specific remote data access

Mappers
    Kimia DTO ↔ GoldPlatform domain conversion

Services
    GoldPlatform business workflows

Enums
    Account types, product types, voucher actions, and similar constants
```

---

## 9. Naming policy

Kimia data models must not be confused with GoldPlatform domain models.

Recommended names:

```text
KimiaAccountDto
KimiaAccountGroupDto
KimiaProductDto
KimiaCoinDto
KimiaCurrencyDto
KimiaBalanceDto
```

Do not map Kimia `ProductDto` directly to the main GoldPlatform `Product` model.

Kimia Product and GoldPlatform Product are different concepts and may evolve independently.

---

## 10. Error-handling policy

Remote API failures must not silently become empty lists or null unless the caller explicitly requests tolerant behavior.

Recommended categories:

```text
KimiaAuthenticationException
KimiaValidationException
KimiaNotFoundException
KimiaConflictException
KimiaRateLimitException
KimiaServerException
KimiaConnectionException
KimiaUnexpectedResponseException
```

Every mutating operation should log:

- endpoint
- method
- safe request identifier
- HTTP status
- Kimia response
- duration
- GoldPlatform user or process identifier

Secrets and credentials must never be logged.

---

## 11. Idempotency policy

For schemas supporting `RequestId`, GoldPlatform should:

1. Generate UUID v4
2. Save it before sending the request
3. Reuse it on safe retries
4. Never generate a new ID for the same business operation retry
5. Store the Kimia response identifier
6. Prevent duplicate local confirmation

This is especially important for:

- adjustments
- transfers
- wallet payments
- trades
- exchange operations

---

## 12. Master-data synchronization

The log pattern suggests these endpoints behave as master data:

```text
/api/account
/api/product
/api/product/coins
/api/product/currencies
```

Recommended GoldPlatform approach:

- Cache remote master data
- Store last successful sync time
- Keep remote identifiers
- Avoid calling full lists on every customer request
- Use a scheduled sync job
- Preserve the last valid snapshot if Kimia is temporarily unavailable
- Mark records stale instead of silently deleting them

The exact synchronization interval is a project decision. The observed external system uses an approximately ten-minute pattern.

---

## 13. Security requirements

Kimia credentials must exist only in environment variables.

Expected configuration keys:

```env
KIMIA_BASE_URL=
KIMIA_USERNAME=
KIMIA_PASSWORD=
KIMIA_TIMEOUT=30
```

Additional security rules:

- Never expose Kimia credentials to frontend code
- Never return raw Kimia exceptions to customers
- Redact authorization headers and tokens from logs
- Restrict Kimia debug routes to local/admin environments
- Protect any internal log viewer with authentication and authorization
- Validate all outgoing DTOs before transmission

---

## 14. Implementation status matrix

| Area | Swagger reviewed | Runtime observed | GoldPlatform reviewed | Status |
|---|---:|---:|---:|---|
| Account list | Yes | Yes | Yes | Needs correction |
| Account create | Yes | No | Yes | Contract review pending |
| Account update | Yes | No | Yes | Contract review pending |
| Account groups | Yes | No | Yes | Partially reviewed |
| Product list | Yes | Yes | Not fully | Ready for implementation audit |
| Coin list | Yes | Yes | Not fully | Schema details pending |
| Currency list | Yes | Yes | Not fully | Schema details pending |
| Balance | Partial | Yes | Not fully | Schema known |
| Transactions | Endpoint visible | Yes | Not fully | Response schema pending |
| Money transfer | Endpoint visible | Yes | Not fully | Request schema must be reconciled |
| Adjustment | Schema known | No | Not fully | Ready for design |
| Wallet | Endpoint map visible | No | Not fully | Detailed audit pending |
| Barcode | Endpoint map visible | No | Not fully | Detailed audit pending |
| RFID | Endpoint map visible | No | Not fully | Detailed audit pending |
| Reports | Partial | Yes | Not fully | Detailed audit pending |

---

## 15. Pending schema extraction

The following schemas still need full extraction:

```text
BarcodeDto
CoinDto
CurrencyDto
ExchangeCurrencyRequest
ExchangeRequest
RecordDto
RecordDtoPagedList
RFIDDto
TradeBarcodeRequest
TradeCashRequest
TradeCurrencyRequest
TransferRequest
VoucherDto
WalletDto
WalletPaymentRequest
WalletPaymentTransferRequest
WalletRequest
```

`PeakDto`, `ProductDto`, `AccountDto`, `AccountGroupDto`, `AdjustmentRequest`, and `BalanceDto` have been partially or fully documented.

---

## 16. Required next audit steps

1. Export the full Swagger path list from `swagger.json`.
2. Export each request and response schema.
3. Match every endpoint to current project classes.
4. Identify dead or duplicate Kimia implementations.
5. Create an endpoint implementation matrix.
6. Add integration tests against mocked Kimia responses.
7. Add a controlled live connection test.
8. Refactor only after the audit is complete.
9. Commit each domain refactor separately.
10. Update this document after every verified change.

---

## 17. Decisions recorded

### Decision 1
Swagger JSON is the primary source of truth.

### Decision 2
No duplicate Kimia class will be deleted before usage verification.

### Decision 3
Kimia DTOs will be kept separate from GoldPlatform domain models.

### Decision 4
The integration will be divided by domain instead of one large service.

### Decision 5
Mutating operations must support safe retry and idempotency where the API allows it.

### Decision 6
Runtime behavior will be compared with Swagger before changing production-facing code.

---

## 18. Known uncertainties

The following points are not yet confirmed:

- Exact schema of `AccountCode`
- Whether `/api/account/{id}` exists outside the reviewed Swagger path
- Exact meaning of numeric response `75030` from `transfermoney`
- Full query parameters for Barcode and RFID endpoints
- Full request/response contracts for Wallet operations
- Exact sign convention for positive and negative balance values
- Whether all mutation endpoints support `RequestId`
- Whether the ten-minute request pattern belongs to Kimia itself or another connected application

These items must remain marked as unknown until verified.

---

## 19. Final architecture target

```text
GoldPlatform Domain
        ↓
Application Services
        ↓
Kimia Repositories
        ↓
Kimia DTOs and Mappers
        ↓
Kimia HTTP Client
        ↓
Kimia API
```

Kimia-specific field names, numeric codes, authentication behavior, and remote exceptions must stop at the integration boundary and must not leak through the entire GoldPlatform codebase.

---

**End of document**
