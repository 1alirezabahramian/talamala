# GoldPlatform — Domain Workshop, Business Rules & Kimia Contract

**Document:** `docs/41_GOLDPLATFORM_DOMAIN_WORKSHOP_2026-07-28.md`  
**Workshop date:** 2026-07-28 / 2026-07-29  
**Status:** Accepted working contract  
**Domain expert and product owner:** Alireza Bahramian  
**Project:** GoldPlatform  

---

## 1. Purpose

این سند نتیجه جلسه تحلیل دامنه GoldPlatform درباره حسابداری طلا، اتصال کیمیا، مانده‌ها، محصولات، قیمت‌گذاری، سفارش‌ها، معاملات، محصولات فیزیکی، انبار، امانات و تحویل است.

هدف سند:

- جلوگیری از حدس در منطق مالی؛
- ثبت تجربه عملی کار با کیمیا؛
- تفکیک زاویه دید مشتری از زاویه دید فروشگاه؛
- تعیین مرز مسئولیت GoldPlatform و Kimia؛
- ایجاد قرارداد مرجع برای Backend، Frontend و تست؛
- جلوگیری از تغییر خاموش تصمیم‌های تأییدشده.

قاعده اصلی:

> **NO GUESSING — برای منطق کیمیا، حسابداری طلا و رفتار پلتفرم، ابتدا از Domain Expert سؤال شود و در صورت نیاز سند واقعی آزمایشی در کیمیا یا پلتفرم رقیب ثبت شود.**

---

## 2. Domain Expert

علیرضا بهرامیان در این پروژه فقط ایده‌پرداز یا کارفرما نیست و نقش رسمی او باید به‌عنوان **Domain Expert و تأییدکننده منطق مالی** در نظر گرفته شود.

سوابق مرتبط:

- تحصیلات اولیه در الکترونیک؛
- مدیریت بازرگانی؛
- گذراندن MBA و DBA؛
- دوره‌های مالی و مالیاتی؛
- حسابداری تخصصی طلا؛
- آشنایی و کار با چندین نرم‌افزار حسابداری؛
- تجربه تخصصی با چند سیستم حسابداری؛
- ۱۵ سال تجربه ترکیبی مدیریت فروش و مدیریت بازرگانی؛
- ۳ سال تجربه مستقیم فروشندگی طلا؛
- تسلط کامل بر حسابداری و نرم‌افزار کیمیا؛
- تجربه عملی با پلتفرم‌های رقیب؛
- طراح ایده و منطق اصلی GoldPlatform.

### روش تصمیم‌گیری

هرگاه یکی از موضوعات زیر مبهم بود، توسعه باید متوقف و سؤال دقیق مطرح شود:

- معنی Action یا Code در کیمیا؛
- اثر یک سند بر مانده مشتری؛
- Request/Response واقعی API؛
- نحوه ثبت خرید، فروش، دریافت یا پرداخت؛
- تبدیل وزن و عیار؛
- نحوه رفتار پلتفرم رقیب؛
- چرخه سفارش، امانت، تحویل یا فروش مجدد؛
- قیمت‌گذاری، اهرم یا کارمزد.

فرایند:

```text
ابهام
→ سؤال دقیق
→ توضیح Domain Expert
→ در صورت نیاز ثبت سند آزمایشی
→ دریافت Raw JSON و مانده قبل/بعد
→ ثبت تصمیم در مستندات
→ Implementation
→ Test
```

---

## 3. Source of Truth and System Boundaries

### 3.1 Kimia

کیمیا منبع حقیقت موارد زیر است:

- مانده ریالی؛
- مانده طلای ۱۸ عیار؛
- مانده سکه؛
- مانده ارز؛
- اسناد مالی؛
- عملیات خرید، فروش، دریافت و پرداخت؛
- موجودی انبار فروشگاه.

### 3.2 GoldPlatform

GoldPlatform منبع حقیقت موارد زیر است:

- تجربه کاربری؛
- سفارش‌ها و تأیید مدیر؛
- قیمت قفل‌شده سفارش؛
- قوانین گروه مشتری؛
- اهرم قیمت‌گذاری؛
- نگاشت محصول پلتفرم به محصول کیمیا و API قیمت؛
- دفتر امانات مشتری؛
- محل فیزیکی کالای امانی؛
- درخواست تحویل یا فروش مجدد؛
- سوابق تحویل؛
- خطاها و تطبیق اتصال کیمیا.

### 3.3 Custody is not a Kimia balance

کیمیا فقط چهار نوع مانده مالی را نشان می‌دهد:

```text
Money
Gold
Coin
Currency
```

پارسیان، شمش، آب‌شده استاندارد و سایر محصولات ساخته‌شده در مانده حساب مشتری در کیمیا نمایش داده نمی‌شوند. کیمیا نمی‌داند کدام کالا در قسمت امانات مغازه نگهداری می‌شود.

بنابراین:

> **Custody Ledger باید در GoldPlatform مستقل ساخته شود.**

---

## 4. Kimia Account API — Confirmed Contract

### 4.1 List accounts

```http
GET /api/account
```

قواعد قطعی:

- هیچ پارامتر اجباری ندارد.
- پاسخ موفق آرایه مستقیم `AccountDto[]` است.
- پاسخ Envelope مانند `Items` یا `Data` ندارد.
- احراز هویت Basic Auth است.
- `X-Book-Id` برای این Endpoint لازم نیست.
- بدون فیلتر باید تمام حساب‌ها را برگرداند.
- اگر حسابی وجود نداشته باشد، پاسخ `[]` است.

فیلتر صحیح نوع حساب:

```http
GET /api/account?Type=3
```

نام پارامتر دقیقاً `Type` است، نه `accountType`.

### 4.2 Account groups

```http
GET /api/account/groups?accountType=3
```

در این Endpoint نام پارامتر دقیقاً `accountType` است.

پاسخ:

```json
[
  {
    "Id": 1,
    "Name": "تکفروشی",
    "AccountType": 3
  }
]
```

### 4.3 Root cause of Account Sync = 0

کد فعلی `AccountRepository::all()` از نام پارامتر اشتباه `accountType` برای `/api/account` استفاده می‌کند. پارامتر صحیح `Type` است.

مشکل دوم این است که خطای HTTP یا پاسخ ناموفق به `[]` تبدیل می‌شود و علت خطا مخفی می‌ماند.

اقدام لازم:

1. تغییر پارامتر به `Type`؛
2. لاگ Status Code و Raw Body؛
3. تفکیک پاسخ خالی واقعی از خطای HTTP؛
4. اجرای درخواست‌های واقعی:

```http
GET /api/account
GET /api/account?Type=3
GET /api/account?Type=3&IsVisible=true
```

5. اجرای مجدد:

```bash
php artisan kimia:sync-accounts
```

6. بررسی `Account::count()`.

---

## 5. Kimia Balance API — Real Response

درخواست واقعی:

```http
GET /api/voucher/balance/350?includePeaks=false
```

پاسخ واقعی:

```json
[
  {
    "Weight": 1,
    "Money": -2999219914,
    "CurrencyId": 11,
    "CurrencySymbol": "ریال"
  },
  {
    "Weight": 0,
    "Money": 500,
    "CurrencyId": 12,
    "CurrencySymbol": "$"
  },
  {
    "Money": 1,
    "CurrencyId": 16,
    "CurrencySymbol": "امامی"
  }
]
```

نمایش واقعی در رابط کیمیا:

| دارایی | مقدار API | نمایش | وضعیت |
|---|---:|---:|---|
| ریال | `-2,999,219,914` | `299,921,991 تومان` | بدهکار |
| طلای ۱۸ عیار | `Weight = 1` | `۱ گرم` | بستانکار |
| دلار | `Money = 500` | `$500` | بستانکار |
| سکه امامی | `Money = 1` | `۱ عدد` | بستانکار |

قواعد قطعی:

```text
مقدار منفی = بدهکار
مقدار مثبت = بستانکار
مقدار صفر = تسویه
```

### 5.1 Meaning of Money depends on CurrencyId

فیلد `Money` همیشه مبلغ ریالی نیست.

```text
CurrencyId = 11 → مقدار ریالی
CurrencyId = 12 → تعداد واحد دلار
CurrencyId = 16 → تعداد سکه امامی
```

پس Mapping نباید فقط براساس نام فیلد `Money` انجام شود. معنا و واحد با `CurrencyId` تعیین می‌شود.

### 5.2 Optional response fields

در پاسخ واقعی برخی فیلدهای موجود در Schema مانند موارد زیر ارسال نشدند:

```text
AccountId
AccountName
GroupId
```

Mapper باید این فیلدها را Optional در نظر بگیرد.

---

## 6. Currency and Coin Catalogs

### 6.1 Currencies

```http
GET /api/product/currencies
```

پاسخ مستقیم `CurrencyDto[]`:

```json
[
  {
    "CurrencyId": 1,
    "Name": "دلار",
    "IsVisible": true
  }
]
```

### 6.2 Coins

```http
GET /api/product/coins
```

پاسخ مستقیم `CoinDto[]`:

```json
[
  {
    "CoinId": 10006,
    "Name": "سکه تمام امامی",
    "Fineness": 900,
    "Weight": 8.133,
    "Type": 15,
    "IsVisible": true
  }
]
```

قواعد:

- `Type = 15`: سکه بانکی؛
- `Type = 17`: سکه متفرقه؛
- هیچ‌یک Query یا Header اجباری ندارند؛
- `X-Book-Id` لازم نیست؛
- احراز هویت Basic Auth است؛
- پاسخ آرایه مستقیم است؛
- `IsVisible` در GoldPlatform قابل فیلتر است؛
- سکه و ارز نباید Hard-Code شوند.

---

## 7. Product Identity

یک محصول در کیمیا می‌تواند دو شناسه متفاوت داشته باشد:

### 7.1 Mutable shortcut/search code

مثال:

```text
سکه امامی: 10006
پارسیان دو گرمی: 2000
```

این کد:

- برای Shortcut و جست‌وجوی سریع هنگام ثبت سند استفاده می‌شود؛
- توسط کاربر کیمیا قابل تغییر است؛
- نباید کلید اتصال پایدار GoldPlatform باشد.

### 7.2 Immutable Kimia ID

مثال:

```text
سکه امامی: Kimia ID = 16
```

این ID:

- قابل تغییر نیست؛
- باید برای اتصال پایدار GoldPlatform به محصول کیمیا استفاده شود.

### 7.3 GoldPlatform product identity

نام و دسته‌بندی محصول در GoldPlatform مستقل از نام کیمیا است.

مثال:

```text
دسته: سکه‌های بانکی
محصول: سکه تمام امامی بانکی ۸۶
Kimia ID: 16
Kimia Shortcut Code: 10006
API Price Key: emami
```

مثال:

```text
دسته: پارسیان
محصول: پلاک پارسیان ۲ گرمی
Kimia ID: <immutable id>
Kimia Shortcut Code: 2000
API Price Key: <configured key>
```

حداقل فیلدهای محصول:

```text
name
category_id
kimia_id
kimia_shortcut_code
api_price_key
physical_weight
fineness
equivalent_weight_750
quantity_unit
is_buyable
is_sellable
is_active
```

---

## 8. Customer View vs Kimia View

رابط مشتری از زاویه دید مشتری صحبت می‌کند، ولی کیمیا از زاویه دید فروشگاه.

| اقدام در پنل مشتری | عملیات فروشگاه در کیمیا | Action |
|---|---|---:|
| خرید | فروش به مشتری | 4 |
| فروش | خرید از مشتری | 3 |
| دریافت کالا/وجه | پرداخت به مشتری | 2 |
| پرداخت یا تحویل به فروشگاه | دریافت از مشتری | 1 |

در مدل باید این دو فیلد جدا باشند:

```text
customer_intent
kimia_action
```

تبدیل فقط در Kimia Adapter انجام شود.

---

## 9. Kimia Actions and Contextual Line Codes

### 9.1 Main actions

| Action | معنی |
|---:|---|
| 1 | دریافت از مشتری |
| 2 | پرداخت به مشتری |
| 3 | خرید از مشتری |
| 4 | فروش به مشتری |

### 9.2 Receive

نمونه‌ها:

```text
Action 1 + Type 7 = دریافت حواله
Action 1 + Type 5 = دریافت نقدی
Action 1 + Type 1 = دریافت آب‌شده
Action 1 + Type 2 = دریافت متفرقه
Action 1 + Product = دریافت کالا
```

مثال:

```text
Action = 1
Product = سکه امامی
Shortcut Code = 10006
Quantity = 2
```

نتیجه: مشتری در مانده سکه، دو عدد بستانکار می‌شود.

مثال حواله:

```text
Action = 1
Type = 7
Bank = بانک ملت
Code = 105
Amount = 100,000,000 ریال
```

نتیجه: مشتری به همان مبلغ بستانکار می‌شود.

### 9.3 Pay

```text
Action 2 + Type 7 = پرداخت حواله
Action 2 + Type 5 = پرداخت نقدی
Action 2 + Type 1 = پرداخت آب‌شده
Action 2 + Product = پرداخت کالا
```

مثال:

```text
Action = 2
Product = نیم سکه
Shortcut Code = 10007
Quantity = 1
```

نتیجه: مانده نیم‌سکه مشتری بدهکار می‌شود یا از طلب قبلی او کسر می‌شود.

### 9.4 Buy from customer

```text
Action 3 + Type 1 = خرید آب‌شده
Action 3 + Type 2 = خرید متفرقه
Action 3 + Type 4 = خرید پولی طلای کاغذی
Action 3 + Type 8 = خرید پولی سکه و ارز
Action 3 + Product = خرید کالای واقعی از مشتری
```

### 9.5 Sell to customer

```text
Action 4 + Type 1 = فروش آب‌شده
Action 4 + Type 2 = فروش متفرقه
Action 4 + Type 4 = فروش پولی طلای کاغذی
Action 4 + Type 8 = فروش پولی سکه و ارز
Action 4 + Product = فروش کالای واقعی به مشتری
```

### 9.6 Code 8 is contextual

کد ۸ بدون دانستن Action معنی واحد ندارد.

در حالت دریافت/پرداخت:

```text
Action = 1 or 2
Code 8 = کسر و اضافه
```

در حالت خرید/فروش:

```text
Action = 3 or 4
Type 8 = معامله پولی سکه و ارز
```

پس معنی باید با ترکیب زیر تعیین شود:

```text
Meaning = Action + LineTypeCode
```

ساخت Enum عمومی و بدون Context برای `Code 8` ممنوع است.

---

## 10. Currency Unit Contract

واحد پولی کیمیا ریال و واحد پولی GoldPlatform تومان است.

```text
Kimia:        1,870,000,000 IRR
GoldPlatform:   187,000,000 TOMAN
```

تبدیل:

```text
Read from Kimia: Toman = Rial ÷ 10
Write to Kimia:  Rial = Toman × 10
```

این تبدیل فقط در Kimia Adapter انجام شود.

قواعد:

- Domain پلتفرم با تومان کار می‌کند؛
- تبدیل با Decimal/Integer انجام شود، نه Float؛
- نام فیلدها واحد را مشخص کند؛
- تبدیل قیمت API و تبدیل Kimia Adapter دوبار اعمال نشوند.

نمونه نام:

```text
amount_toman
kimia_amount_rial
base_price_toman
customer_buy_price_toman
customer_sell_price_toman
```

---

## 11. API Price Mapping Formula

قیمت خام API ممکن است با واحد یا ساختاری متفاوت از نیاز پلتفرم ارائه شود.

برای هر محصول هنگام اتصال به API باید فرمول مستقل ثبت شود:

\[
BasePrice = \left(\frac{ApiPrice}{x}\right)\times y+z
\]

تعریف:

| متغیر | معنی |
|---|---|
| `ApiPrice` | قیمت خام API |
| `x` | مقسوم‌علیه |
| `y` | ضریب |
| `z` | عدد ثابت مثبت یا منفی |

### 11.1 Rial to Toman

```text
x = 10
y = 1
z = 0
```

### 11.2 Mesghal to Gold 18K

```text
x = 4.3318
y = 1
z = 0
```

### 11.3 Rounding

پس از اجرای فرمول، قیمت به نزدیک‌ترین مقدار استاندارد گرد می‌شود.

```text
rounding_digits = 4
```

یعنی گردکردن چهار رقم آخر یا مضرب `10,000`.

مثال:

```text
17,631,284.73
→ 17,630,000
```

ترتیب:

```text
Raw API Price
→ x/y/z Formula
→ Standard Rounding
→ Customer Group Lever
→ Final Buy/Sell Price
```

محاسبات با Decimal انجام شود.

---

## 12. Customer Group Price Levers

برای هر گروه مشتری و هر محصول دو اهرم مستقل وجود دارد:

- فروش پلتفرم به مشتری؛
- خرید پلتفرم از مشتری.

اهرم می‌تواند:

```text
Fixed Amount
Percentage
```

باشد و قابلیت کم یا زیادکردن داشته باشد.

### 12.1 Example — normal customers

```text
API/Base Price: 187,000,000 تومان
Sell-to-customer lever: +1,000,000
Buy-from-customer lever: -3,000,000
```

نمایش از دید مشتری:

```text
قیمت خرید شما: 188,000,000
قیمت فروش شما: 184,000,000
```

### 12.2 Example — VIP customers

```text
API/Base Price: 187,000,000 تومان
Sell-to-customer lever: 0
Buy-from-customer lever: -2,000,000
```

نمایش:

```text
قیمت خرید شما: 187,000,000
قیمت فروش شما: 185,000,000
```

### 12.3 Percentage example

برای طلای ۱۸ عیار ممکن است:

```text
فروش به مشتری: +1%
خرید از مشتری: -2%
```

باشد.

---

## 13. Financial Trading Order Workflow

این بخش برای طلای ۱۸ عیار، سکه و ارز است.

### 13.1 Customer input

مشتری می‌تواند سفارش را براساس یکی از این دو حالت ثبت کند:

- وزن/تعداد؛
- مبلغ تومانی.

مثال:

```text
وزن = 1.200 گرم
```

یا:

```text
مبلغ = 50,000,000 تومان
```

### 13.2 Price snapshot

هنگام ثبت سفارش، قیمت برای مشتری ثابت می‌ماند تا مدیر تصمیم بگیرد.

Snapshot لازم:

```text
product_id
customer_id
side
input_mode
requested_weight
requested_quantity
requested_amount_toman
api_raw_price
base_price_toman
customer_group_lever
locked_price_toman
formula_snapshot
expires_at
status
```

تغییر بعدی API، فرمول یا گروه مشتری نباید سفارش قبلی را تغییر دهد.

### 13.3 Admin approval

پس از ثبت سفارش:

- اعلان داخل پنل مدیر ایجاد می‌شود؛
- امکان اعلان روی موبایل مدیر وجود دارد؛
- مدیر زمان محدودی برای بررسی دارد؛
- زمان می‌تواند برای هر فرد یا گروه قابل تنظیم باشد؛
- نمونه: ۳، ۵ یا ۶ دقیقه.

مدیر می‌تواند:

- تأیید کند؛
- رد کند؛
- دلیل رد را ثبت کند؛
- اجازه دهد سفارش منقضی شود.

مدیر سفارش منقضی‌شده را مشاهده می‌کند و با ثبت Audit Log می‌تواند آن را ویرایش، تأیید یا رد کند.

### 13.4 Order statuses

```text
pending_admin
approved
rejected
expired
kimia_processing
kimia_failed
completed
cancelled
```

### 13.5 Automatic approval

سیستم باید از حالت‌های زیر پشتیبانی کند:

```text
manual
automatic
rule_based
```

نمونه قوانین:

- معاملات خودکار در بازه ۱۴ تا ۱۶؛
- معاملات طلای کمتر از ۱۰ گرم خودکار؛
- معامله کمتر از ۵ سکه خودکار؛
- مقادیر بیشتر نیازمند تأیید مدیر؛
- قانون متفاوت برای محصول یا گروه مشتری.

### 13.6 Completion rule

پس از تأیید:

```text
Approved Order
→ Send to Kimia
→ Kimia Success
→ Read New Balance
→ Mark Completed
→ Notify Customer
```

سفارش فقط پس از موفقیت سند کیمیا `completed` می‌شود.

اگر کیمیا خطا داد:

```text
status = kimia_failed
```

- مانده محلی قطعی تغییر نکند؛
- پیام موفقیت ارسال نشود؛
- خطا در نمایشگر کیمیا ثبت شود؛
- Retry یا Cancel با Audit Log انجام شود.

---

## 14. Kimia Integration Monitor

پنل مدیریتی «نمایشگر کیمیا» باید حداقل شامل موارد زیر باشد:

```text
نوع عملیات
شماره سفارش
مشتری
زمان ارسال
Request ID
HTTP Status
Error Body
تعداد تلاش
آخرین زمان تلاش
وضعیت تطبیق
شماره سند کیمیا
```

عملیات:

- Retry؛
- مشاهده جزئیات؛
- Reconcile؛
- Mark Resolved؛
- Cancel.

خطای مالی حذف فیزیکی نشود؛ فقط `resolved` یا `cancelled` شود.

### Open issue: idempotency

باید در Swagger و API واقعی بررسی شود که آیا هنگام ثبت سند می‌توان یکی از موارد زیر را ارسال و بعداً جست‌وجو کرد:

```text
ReferenceId
ExternalId
Unique Request Number
Comment
```

هدف: جلوگیری از ثبت دوباره سند در حالتی که کیمیا سند را ثبت کرده ولی پاسخ به GoldPlatform نرسیده است.

---

## 15. Deposit and Payment Requests

### 15.1 Upload bank receipt

```text
Customer uploads receipt
→ Pending admin review
→ Admin checks bank account
→ Admin confirms
→ Kimia receipt document
→ Read new balance
→ Complete request
```

نمونه سند:

```text
Action = 1
Type = 7
Bank/Product = destination bank
Amount = Toman × 10
```

### 15.2 Online payment gateway

درگاه بانکی نیز در نهایت باید همان نتیجه مالی را ایجاد کند. تفاوت آن با فیش فقط در روش اثبات و تأیید پرداخت است.

---

## 16. Physical Product Purchase

محصولات فیزیکی شامل:

- پارسیان؛
- شمش ۲۴ عیار؛
- آب‌شده استاندارد؛
- سکه فیزیکی؛
- سایر محصولات ساخته‌شده.

### 16.1 Two payment modes

هر محصول می‌تواند از یکی از صندوق‌های زیر خریداری شود:

- صندوق تومانی؛
- صندوق طلایی.

### 16.2 Cash payment

قیمت فروش محصول از API همان محصول گرفته می‌شود:

```text
CashCost = ProductSellPriceFromAPI
```

### 16.3 Gold payment

معادل طلایی همان لحظه محاسبه می‌شود:

\[
GoldCost=
\frac{ProductSellPriceFromAPI}{CurrentGold18Price}
\]

مثال:

```text
Product price = 37,000,000 تومان
Gold18 price = 18,271,604 تومان
Gold cost ≈ 2.025 گرم
```

بنابراین معادل طلایی فقط «وزن + اجرت ثابت» نیست و با نسبت قیمت لحظه‌ای محصول به قیمت لحظه‌ای طلای ۱۸ تعیین می‌شود.

### 16.4 Product specification snapshot

هنگام تعریف کالا:

```text
physical_weight
fineness
equivalent_weight_750
kimia_id
kimia_shortcut_code
api_price_key
```

در هر سفارش نیز Snapshot این مشخصات نگهداری شود.

---

## 17. Physical Purchase and Custody Flow

هنگام قطعی‌شدن خرید فیزیکی:

```text
Confirm purchase
→ Register Kimia product payment (Action 2)
→ Reduce Kimia store inventory
→ Settle customer gold/cash source
→ Create custody record in GoldPlatform
→ Store employee separates item
→ Move item to store custody location
```

کیمیا فقط می‌فهمد محصول از موجودی قابل‌فروش فروشگاه خارج شده است. مالکیت و محل امانت در GoldPlatform ثبت می‌شود.

### 17.1 Custody ownership

```text
Owner = Customer
Physical Location = Store Custody Area
System of Record = GoldPlatform
```

### 17.2 Employee task

کارمند باید:

- محصول را از موجودی فروش جدا کند؛
- مشخصات آن را کنترل کند؛
- به بخش امانات مغازه منتقل کند؛
- انتقال را در پلتفرم تأیید کند.

اطلاعات لازم:

```text
product
quantity
weight
owner
order_number
previous_location
custody_location
employee
separated_at
```

اگر بارکد، RFID، سریال یا مشخصه فیزیکی وجود دارد، همان قطعه مشخص به امانت متصل شود.

### 17.3 Custody statuses

```text
awaiting_separation
separating
in_store_custody
pickup_requested
sale_requested
ready_for_pickup
delivered
resold_to_store
cancelled
```

---

## 18. Physical Delivery

وقتی مشتری کالا را از اپراتور مغازه تحویل می‌گیرد:

```text
in_store_custody
→ pickup_requested
→ ready_for_pickup
→ delivered
```

در لحظه تحویل واقعی:

- سند مالی جدیدی در کیمیا ثبت نمی‌شود؛
- مانده دوباره کم نمی‌شود؛
- موجودی دوباره کم نمی‌شود؛
- فقط وضعیت در GoldPlatform تغییر می‌کند؛
- زمان تحویل و کارمند تحویل‌دهنده ثبت می‌شوند.

رکورد حذف نشود؛ به `delivered` منتقل شود تا تاریخچه باقی بماند.

---

## 19. Customer Choices for Custody Assets

مشتری برای کالای موجود در امانات دو انتخاب اصلی دارد:

1. درخواست تحویل فیزیکی؛
2. فروش مجدد به فروشگاه.

فروش مجدد دو خروجی دارد:

- تبدیل به صندوق طلایی؛
- تبدیل به صندوق تومانی.

---

## 20. Resale to Gold Balance

اگر مشتری کالای امانی را به صندوق طلایی تبدیل کند:

```text
Kimia Action = 1 (Receive from customer)
Product = Custody product
Price = Not required
```

نتیجه:

- کالا از امانت مشتری خارج می‌شود؛
- مالکیت به فروشگاه برمی‌گردد؛
- محصول به موجودی فروشگاه بازمی‌گردد؛
- معادل طلای ۷۵۰ محصول به صندوق طلایی مشتری اضافه می‌شود.

اجرت و سود اولیه فروشگاه برگشت داده نمی‌شود.

### 20.1 Gold 750 equivalent

\[
EquivalentWeight_{750}=
\frac{PhysicalWeight\times Fineness}{750}
\]

مثال پارسیان ۲ گرمی عیار ۷۵۰:

```text
2.000 × 750 ÷ 750 = 2.000 گرم
```

اگر مشتری هنگام خرید `2.025` گرم پرداخته باشد، هنگام برگشت فقط `2.000` گرم دریافت می‌کند. مقدار `0.025` گرم اجرت و سود فروشگاه بوده است.

مثال سکه تمام با وزن `8.133` و عیار `900`:

```text
8.133 × 900 ÷ 750 = 9.7596 گرم طلای ۷۵۰
```

این مقدار به صندوق طلایی اضافه می‌شود.

---

## 21. Resale to Cash Balance

اگر مشتری کالای امانی را پولی بفروشد:

```text
Kimia Action = 3 (Buy from customer)
Product = Custody product
Quantity = Custody quantity
Unit Price = Current buyback price
```

نتیجه:

- کالا از امانات خارج می‌شود؛
- مالکیت به فروشگاه برمی‌گردد؛
- کالا به موجودی فروشگاه بازمی‌گردد؛
- مبلغ فروش به مانده تومانی مشتری اضافه می‌شود.

قیمت خرید مجدد هر محصول از API و تنظیمات همان محصول محاسبه می‌شود:

```text
API Price Key
x/y/z Formula
Product Buy Lever
Customer Group Lever
Rounding Digits
Quantity
```

محاسبه نهایی باید Snapshot شود و مبلغ تومان هنگام ارسال به کیمیا در ۱۰ ضرب شود.

---

## 22. Wage and Profit on Physical Products

محصول فیزیکی می‌تواند اجرت‌های متفاوت داشته باشد:

- اجرت تومانی؛
- اجرت درصدی؛
- اجرت وزنی.

### 22.1 Gold-weight wage example

پارسیان ۲ گرمی:

```text
Product weight = 2.000 g
Gold wage/profit = 0.025 g
Gold cost = 2.025 g
```

برای ثبت اجرت وزنی در کیمیا، ردیف مجزا با Context دریافت/پرداخت و کد «کسر و اضافه» ایجاد می‌شود.

```text
Action = 2
Line Type = Adjustment
Contextual Code = 8
Item = Construction Wage
Weight = 0.025 g
```

این Code 8 با Code 8 معامله پولی سکه و ارز یکی نیست؛ Context Action معنی آن را تعیین می‌کند.

---

## 23. Prototype Page Review

صفحه نمونه `1.html` توسط Product Owner برای توضیح تجربه کاربری بخش محصولات فیزیکی طراحی شده است.

قابلیت‌های نمونه:

- دسته‌بندی سکه بانکی، سایر سکه‌ها، پارسیان، شمش و آب‌شده؛
- دریافت قیمت محصول از API؛
- نمایش صندوق پولی و صندوق طلایی؛
- انتخاب تعداد؛
- سبد خرید؛
- صدور فاکتور.

منطق فعلی نمونه:

```javascript
goldUnitPrice = productCashPrice / gold18Price;
```

این منطق با تصمیم کسب‌وکار تطابق دارد.

اما نمونه فعلی Demo است و این موارد را ندارد:

- Backend واقعی؛
- مانده واقعی کیمیا؛
- Kimia ID؛
- فرمول x/y/z؛
- اهرم گروه مشتری؛
- گردکردن تنظیمی؛
- موجودی واقعی؛
- Custody Ledger؛
- درخواست تحویل؛
- فروش مجدد؛
- Audit Log؛
- Kimia Integration Monitor.

در نسخه نهایی، `localStorage` و کسر مستقیم مرورگر حذف و با Backend و کیمیا جایگزین شود.

---

## 24. Required Data Models — Conceptual

مدل‌های پیشنهادی مفهومی:

```text
ProductCategory
Product
ProductKimiaMapping
ProductPriceMapping
CustomerGroup
CustomerGroupPriceRule
Order
OrderPriceSnapshot
Trade
KimiaOperation
KimiaOperationAttempt
CustodyAsset
CustodyEvent
InventoryLocation
InventoryMovement
DeliveryRequest
ResaleRequest
PaymentReceipt
AdminDecision
AuditLog
```

### 24.1 CustodyAsset minimum fields

```text
id
customer_id
product_id
order_id
kimia_operation_id
quantity
physical_weight
fineness
equivalent_weight_750
purchase_payment_mode
purchase_cash_toman
purchase_gold_weight
price_snapshot
owner_type
inventory_location_id
status
separated_by
separated_at
ready_at
delivered_by
delivered_at
```

---

## 25. Non-Negotiable Rules

1. Kimia HTTP نباید مستقیماً از Controller فراخوانی شود.
2. Mapping کیمیا باید در Adapter متمرکز باشد.
3. `customer_intent` و `kimia_action` جدا باشند.
4. کد قابل تغییر محصول، کلید اتصال پایدار نیست.
5. اتصال محصول با Kimia ID ثابت انجام شود.
6. سکه‌ها و ارزها Dynamic باشند.
7. `Money` همیشه به معنی ریال نیست.
8. واحد Kimia ریال و واحد پلتفرم تومان است.
9. تبدیل واحد فقط در مرز Adapter انجام شود.
10. Custody با چهار مانده مالی کیمیا ادغام نشود.
11. عملیات مالی ناموفق حذف نشود.
12. سفارش فقط پس از موفقیت کیمیا Completed شود.
13. قیمت و فرمول معامله Snapshot شوند.
14. محاسبات با Decimal انجام شوند.
15. وزن، عیار و معادل ۷۵۰ Snapshot شوند.
16. تحویل فیزیکی تاریخچه داشته باشد و رکورد حذف نشود.
17. تغییرات مدیر روی سفارش منقضی‌شده Audit شود.
18. هیچ Request Body مربوط به کیمیا حدس زده نشود.

---

## 26. Remaining Verification Tasks

موارد زیر هنوز باید با Swagger یا سند واقعی بررسی شوند:

### 26.1 Account sync

- اصلاح `Type`؛
- ثبت Raw Response؛
- اجرای Sync و بررسی Count.

### 26.2 Idempotency

- بررسی External/Reference ID در ثبت سند؛
- بررسی امکان جست‌وجوی سند با شناسه خارجی؛
- طراحی Retry بدون ثبت تکراری.

### 26.3 Exact Kimia request bodies

برای عملیات زیر Request Body دقیق از Swagger/تست استخراج شود:

- خرید/فروش طلای کاغذی؛
- خرید/فروش پولی سکه و ارز؛
- پرداخت محصول فیزیکی؛
- دریافت محصول امانی؛
- خرید پولی محصول امانی؛
- اجرت وزنی/تومانی/درصدی؛
- دریافت حواله و پرداخت حواله.

### 26.4 Weight precision

- دقت ذخیره و نمایش `9.7596` در کیمیا؛
- قانون گردکردن وزن؛
- تعداد ارقام اعشار صندوق طلایی.

### 26.5 Automatic approval precedence

- اولویت قواعد زمان، وزن، تعداد، مبلغ، محصول و گروه مشتری؛
- رفتار در تعارض چند Rule.

---

## 27. Recommended Next Implementation Sequence

1. اصلاح Account Sync و خطایابی شفاف؛
2. ساخت Value Objectهای `MoneyToman`، `MoneyRial` و `GoldWeight`؛
3. ساخت Product Catalog و نگاشت Kimia/API؛
4. ساخت Price Formula و Rounding؛
5. ساخت Customer Group Levers؛
6. اصلاح Order/Trade و حذف Account IDهای Hard-Code؛
7. ساخت Approval Workflow؛
8. ساخت Kimia Operation Outbox/Monitor؛
9. پیاده‌سازی Idempotency؛
10. ساخت Custody Ledger؛
11. ساخت Inventory Location/Movement؛
12. ساخت Delivery و Resale؛
13. تست End-to-End با اسناد آزمایشی کیمیا؛
14. سپس پیاده‌سازی Frontend اصلی براساس Prototype.

---

## 28. Acceptance

این سند بازتاب تصمیم‌های تأییدشده جلسه تحلیل دامنه است و باید پیش از تغییر بخش‌های زیر خوانده شود:

- Kimia Integration؛
- Balance Mapping؛
- Pricing Engine؛
- Orders and Trades؛
- Physical Products؛
- Inventory؛
- Custody؛
- Delivery؛
- Resale.

هر تناقض جدید باید با Domain Expert مطرح و نتیجه در همین سند یا ADR مرتبط ثبت شود.

