# MANIFEST — Stage Backoffice Registration Queue + dev bind

**Date:** 2026-08-15  
**Smoke:** PASS=33 FAIL=0

## Commit-allowed (این Stage)

- `backend/` — شامل Kernel (`POST /v1/dev/bind-kimia`)، `http_smoke.php`، `admin-reg-demo.html`
- `frontend/backoffice/` — صف ثبت‌نام + approve
- `docs/00-master/STAGE_BACKOFFICE_REG_QUEUE.md`
- `docs/00-master/CURRENT_STATE.md`
- `openapi/` (در صورت نیاز parity؛ مسیرهای /v1/dev/* عمداً خارج از OpenAPI)

## Bundled-only / خارج از Commit این Stage

- هیچ مسیر دیگری عمداً در این ZIP نیست.

## تغییرات کلیدی

1. `POST /v1/dev/bind-kimia` — فقط local + `X-Talamala-Dev: 1`؛ bind حساب Kimia موجود + seed اختیاری Fake balance
2. `admin-reg-demo.html` — دکمهٔ اختیاری «Bind Kimia (dev)»
3. smoke: `dev_bind_kimia` + production همچنان /v1/dev/* را 404 می‌کند
4. **بدون** Kimia Write / create account / price / settlement

## Verify

```bash
cd backend
php bin/http_smoke.php   # PASS=33
php -S 127.0.0.1:8080 -t public public/router.php
# admin: http://127.0.0.1:8080/admin-reg-demo.html
# customer OTP → register: http://127.0.0.1:8080/otp-demo.html
```
