# Talamala — Current State (2026-08-13)

## Working vertical (in-memory + fakes)

```
Host → Tenant (fail-closed, multi-tenant isolation)
OTP request (rate-limited 5/5min per tenant+mobile) → verify
  → registration (Jibit gate fake)
  → staff approve
  → Kimia bind (manual id; create write BLOCKED)
  → GET /assets (Kimia read → Toman + gold)
Custody: receive → ready → delivered
Order: accept quote (idempotent) → settlement BLOCKED
```

## HTTP smoke

```bash
cd backend && php bin/http_smoke.php
# PASS=32 FAIL=0
```

Includes: health, tenant isolation (demo + other + unknown), full OTP/register/approve,
staff login+rotate, assets (header + Bearer), custody lifecycle, order accept+idempotency,
OTP rate limit + **cross-tenant rate-limit isolation**, production bearer hardening.

## Security in code

- `SecurityHeaders` (nosniff, DENY frame, no-store, CORS allow-list)
- `InMemoryRateLimiter` on OTP (5 / 300s per tenant+mobile)
- Bearer-only in production; header fallback blocked
- Dev routes gated in production

## OpenAPI

`openapi/*-v1.openapi.yaml` aligned with working routes (v1.3.0): OTP 429 + Retry-After,
register, staff rotate, custody ready/deliver, security notes.

## Stages

| Stage | Status |
|-------|--------|
| 0 Truth & Governance | Closed |
| 1 Foundation | Skeleton complete |
| 2 Identity | Vertical working (fakes) |
| 3 Kimia Read | Vertical working (Fake + Http client ready) |
| Quote / Order write / Price / Payment | BLOCKED by ground truth |
| Custody | HTTP vertical working |
| Frontend | Screen stubs only |

## Blockers (production)

See `GROUND_TRUTH_BLOCKERS.md`
