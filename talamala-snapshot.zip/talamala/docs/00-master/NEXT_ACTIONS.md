# Next Actions

## Done this step
- OpenAPI parity (A) — auth/customer/backoffice v1.3.0
- Adversarial isolation tests (B) — smoke **32/32**
  - otp_rate_limit_isolated_across_tenants
  - tenant_other_readyz
  - tenant_unknown_still_fail_closed

## Ready now
1. Wire customer frontend OTP screens to local PHP server
2. Apply SecurityHeaders on every Kernel response (small hardening)
3. PHPUnit feature tests mirroring the new adversarial cases

## Blocked until ground truth
- Kimia write · Price provider · Payment · live credentials
