# Talamala — Current State (2026-08-15)

## HTTP smoke
`php backend/bin/http_smoke.php` → **PASS=32 FAIL=0**

Includes: tenant isolation (demo + other + unknown), OTP rate-limit + cross-tenant isolation,
full identity vertical, custody lifecycle, order accept+idempotency, production bearer hardening,
assets (Kimia read) + bearer path.

## OpenAPI
v1.3.0 aligned with working routes (429, register, rotate, custody ready/deliver, assets).

## Stage C (frontend OTP → local server) — CLOSED 100%
- `frontend/customer/src/api/client.ts` — baseUrl + X-Talamala-Host (fail-closed tenant)
- `frontend/customer/src/api/auth.ts` — requestOtp / verifyOtp / fetchDevLastOtp / registerCustomer
- `OtpRequestScreen.tsx` + `OtpVerifyScreen.tsx` + `RegistrationScreen.tsx`
- `AppOtpFlow.tsx` — request → verify → register → done
- **Runnable zero-build demo:** `backend/public/otp-demo.html`
  - same-origin with `php -S 127.0.0.1:8080 -t public public/router.php`
  - Host tenant via `X-Talamala-Host: demo.local`
  - Dev helper: GET `/v1/dev/last-otp` with `X-Talamala-Dev: 1`
  - After register/auth: «خواندن دارایی» (GET /v1/customer/assets) — Stage 3 vertical in same page

## Stage D Registration — CLOSED (frontend + demo)
- Contract: POST /v1/auth/customer/register { mobile, national_code, full_name }
- Jibit = verification only; staff approve separate; Kimia create still BLOCKED

## Stage 3 Kimia Read / Customer Financial View — CLOSED (backend + UI)
- HttpKimiaReadClient + FakeKimiaReadClient
- CustomerFinancialReadService (Rial→Toman exact, decimal strings, gold weight)
- GET /v1/customer/assets (Bearer or local X-Customer-Id)
- `frontend/customer/src/api/assets.ts` + `AssetsScreen.tsx`
- `backend/public/assets-demo.html`
- otp-demo now surfaces assets after identity success (expect `not_bound` until staff bind)

## Quote / Order / Custody — backend vertical present
- Quote immutable fixture + accept (idempotent); settlement BLOCKED
- Custody lifecycle: receive → ready → deliver (Talamala truth)
- Customer list endpoints + demos (order-demo, custody-demo)

## Non-negotiables still held
- Kimia = sole truth for Money/Gold/Coin/Currency
- Talamala = sole truth for Physical Custody (Amanat)
- Tenant from verified Host only (fail-closed)
- Decimal strings only
- No invented Action codes / price coefficients / payment contracts
- Kimia Write / live price / settlement remain **BLOCKED BY GROUND TRUTH**

## Next (talago)
1. Polish customer shell continuity (OTP → assets → custody/orders) if needed
2. Backoffice registration queue + Kimia bind UX (admin)
3. Do **not** enable Kimia Write or settlement without new ground-truth evidence
