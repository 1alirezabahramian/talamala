# MANIFEST — Backoffice CSS + log rotate + SPA HTML (multi-step)

## Commit order
1. backoffice styles.css + main import
2. StructuredLogger rotate + env max bytes
3. logger_smoke PASS=8 + CI
4. router.php HTML 503/404 FA
5. spa_router_smoke soft + CI job
6. .env.example + docs

## Expected
```text
php backend/bin/logger_smoke.php → PASS=8 FAIL=0
php backend/bin/spa_router_smoke.php → PASS / FAIL=0
php backend/bin/http_smoke.php → PASS=43 FAIL=0
```
