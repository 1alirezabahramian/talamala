# MANIFEST — talamala-batch-0.3.8-contract-depth-20260817

**Base HEAD:** 2d2a5b1 (0.3.7-phase1)  
**VERSION:** 0.3.8-phase1  
**Scope:** Deep contract pack — many stages in one ZIP

## Stages
| # | Stage | Result |
|---|--------|--------|
| 1 | staff_rotate_requires_staff_id | 401 |
| 2 | staff_rotate_password_reuse | 400 |
| 3 | custody_ready_invalid_id | 400 |
| 4 | order_accept_quote_not_found | 409 |
| 5 | seed_quote_customer_required | 422 |
| 6 | readyz_x_talamala_host | 200 |
| 7 | healthz_version_matches_file | VERSION parity |
| 8 | robots_allows_healthz | landing PASS 18 |
| 9 | Makefile `info` | DX |
| 10 | CI http **78** · landing **18** | |
| 11 | docs + CAP-034/035 | |
| 12 | VERSION **0.3.8-phase1** | |

## Expected
```text
php backend/bin/http_smoke.php    → PASS=78 FAIL=0
php backend/bin/landing_smoke.php → PASS=18 FAIL=0
php backend/bin/check.php         → ALL CHECKS PASSED
```

## Non-goals
Kimia Write · Pricing · Settlement · Payment · Delta · durable tenant resolver
