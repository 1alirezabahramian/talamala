# MANIFEST — VERSION + Makefile + HTML security headers

## Commit order
1. `VERSION` **New**
2. `backend/public/landing.html` — placeholders
3. `backend/public/router.php` — meta inject + HTML headers for demos
4. `Makefile` **New**
5. `landing_smoke` PASS=12 + CI
6. OPERATORS.md + docs

## Expected
```text
php backend/bin/landing_smoke.php → PASS=12 FAIL=0
php backend/bin/http_smoke.php    → PASS=43 FAIL=0
php backend/bin/logger_smoke.php  → PASS=8 FAIL=0
make check                        → ALL CHECKS PASSED
```
