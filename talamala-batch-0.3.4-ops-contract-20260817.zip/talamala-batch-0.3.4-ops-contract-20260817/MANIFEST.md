# MANIFEST — talamala-batch-0.3.4-ops-contract-20260817

**Base HEAD:** d51e538 (0.3.3-phase1)  
**VERSION:** 0.3.4-phase1  
**Direction:** Ops identity + contract negatives + governance docs (no Ground Truth invent)

## Stages

| # | Stage | Result |
|---|--------|--------|
| A | healthz/readyz `version` from VERSION file | HealthController |
| B | http_smoke version asserts | healthz_has_version · readyz_has_version |
| C | order accept without Idempotency-Key → 422 | gated |
| D | http_smoke PASS 51 → **54** + CI gate | |
| E | ADR_INDEX living statuses (Accepted/Partial) | no financial invent |
| F | OpenAPI auth description: correlation + version | info 1.4.0 |
| G | Makefile `domain` target | |
| H | CURRENT_STATE / OPERATORS / LOCAL_RUN / README / Ledger CAP-027/028 | |
| I | VERSION **0.3.4-phase1** | |

## Commit-allowed
- `.github/workflows/ci.yml`
- `VERSION` · `README.md` · `Makefile`
- `backend/app/Http/Controllers/HealthController.php`
- `backend/bin/http_smoke.php`
- `openapi/auth-v1.openapi.yaml`
- `docs/00-master/CURRENT_STATE.md` · `OPERATORS.md` · `LOCAL_RUN.md`
- `docs/00-master/STAGE_BATCH_0_3_4_OPS_CONTRACT.md`
- `docs/adr/ADR_INDEX.md`
- `docs/traceability/CAPABILITY_LEDGER.md`

## Expected tests
```text
php backend/bin/http_smoke.php → PASS=54 FAIL=0
php backend/bin/check.php      → ALL CHECKS PASSED
php backend/bin/smoke.php      → PASS=8 FAIL=0
cat VERSION                    → 0.3.4-phase1
```

## CI gates
http(**54**) · persist(9) · cors(13) · logger(8) · maintenance(7) · spa(6) · landing(17) · openapi-parity · secret-scan  
frontend-typecheck = optional

## Non-goals
Kimia Write · Pricing · Settlement · Payment · Delta · durable multi-tenant resolver
