# MANIFEST — Session tests + logout + readiness hardening

## Commit-allowed
| Path | Change |
|------|--------|
| `backend/app/Http/Kernel.php` | logout route; readyz sqlite check; TTL fix |
| `backend/bin/http_smoke.php` | +session negatives → PASS=41 |
| `backend/bin/openapi_parity_check.php` | expect POST /v1/auth/logout |
| `openapi/auth-v1.openapi.yaml` | logout operation |
| `backend/app/Infrastructure/Logging/StructuredLogger.php` | broader redact |
| `.github/workflows/ci.yml` | http-smoke PASS=41 |
| `frontend/*/src/api/auth.ts` | logout() helper |
| `docs/00-master/*` | CURRENT_STATE + STAGE doc |

## Expected tests
```text
php backend/bin/http_smoke.php → PASS=41 FAIL=0
php backend/bin/persist_smoke.php → PASS=9 FAIL=0
php backend/bin/openapi_parity_check.php → parity OK
```

## Not in scope
Kimia Write / Settlement / Payment / Pricing / Catalog / Delta blind port
