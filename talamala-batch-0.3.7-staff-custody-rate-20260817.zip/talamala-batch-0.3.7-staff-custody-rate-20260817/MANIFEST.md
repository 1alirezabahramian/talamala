# MANIFEST — talamala-batch-0.3.7-staff-custody-rate-20260817

**Base HEAD:** a487d31 (0.3.6-phase1)  
**VERSION:** 0.3.7-phase1

## Stages
1. staff_rotate_password_too_weak → 400
2. staff_rotate_invalid_current → 400
3. custody_receive_unauthorized → 401
4. custody_receive_validation → 422
5. otp_rate_limited_retry_after (retry_after + Retry-After header)
6. healthz_time_iso
7. http_smoke PASS 65 → **71** + CI
8. OpenAPI backoffice custody 401/422
9. docs + CAP-032/033 + VERSION 0.3.7-phase1

## Expected
```text
php backend/bin/http_smoke.php → PASS=71 FAIL=0
php backend/bin/check.php → ALL CHECKS PASSED
```

## Non-goals
Kimia Write · Pricing · Settlement · Payment · Delta · durable tenant resolver
