# MANIFEST — talamala-ci-spa-ledger-0.3.1-20260816

**Base HEAD:** 942be44  
**Date:** 2026-08-16  
**Scope:** Release-readiness polish — exact spa_router CI gate + Capability Ledger + VERSION 0.3.1-phase1

## Commit-allowed
| Path | Action |
|------|--------|
| `.github/workflows/ci.yml` | Patch — spa-router exact PASS=6 FAIL=0 |
| `VERSION` | Replace → `0.3.1-phase1` |
| `docs/00-master/CURRENT_STATE.md` | Replace |
| `docs/00-master/STAGE_CI_SPA_EXACT_LEDGER.md` | New |
| `docs/traceability/CAPABILITY_LEDGER.md` | Replace — CAP-021/022 + notes |

## Bundled-only
- This MANIFEST.md

## Expected tests
```text
php backend/bin/spa_router_smoke.php → PASS=6 FAIL=0
php backend/bin/http_smoke.php       → PASS=49 FAIL=0
php backend/bin/check.php            → ALL CHECKS PASSED
cat VERSION                          → 0.3.1-phase1
```

## CI jobs (green SHA)
php-syntax · http-smoke (49) · persist (9) · cors (10) · logger (8) · maintenance (7) · spa-router (**6**) · landing (13) · openapi-parity · secret-scan  
frontend-typecheck = optional

## Non-goals
No financial invent · no Kimia write · no Delta · no tenant resolver persistence
