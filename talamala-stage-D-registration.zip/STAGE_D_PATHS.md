# Stage D — exact paths (match repo main / Stage C)

## Paths that do NOT exist on main (do not look for them)
- components/auth/RegistrationScreen.tsx
- api/auth.ts
- openapi.json
- backend/public/routes/auth.php

## Real paths in this ZIP (repo-relative)

| Path | Role |
|------|------|
| frontend/customer/src/api/auth.ts | + registerCustomer (OpenAPI body) |
| frontend/customer/src/screens/auth/RegistrationScreen.tsx | form UI |
| frontend/customer/src/AppOtpFlow.tsx | request → verify → register → done |
| backend/public/otp-demo.html | local demo with register step |
| docs/00-master/STAGE_D_REGISTRATION.md | stage note |
| STAGE_D_APPLY.md | apply / commit |

## Backend
POST /v1/auth/customer/register already in Kernel + openapi/auth-v1.openapi.yaml
No new PHP route file required for Stage D.

## Commit (scoped only)

```bash
git add \
  frontend/customer/src/api/auth.ts \
  frontend/customer/src/screens/auth/RegistrationScreen.tsx \
  frontend/customer/src/AppOtpFlow.tsx \
  backend/public/otp-demo.html \
  docs/00-master/STAGE_D_REGISTRATION.md
git commit -m "feat(stage-D): registration form after OTP registration_required"
```
