# Stage D apply (Registration only)

```bash
cd /path/to/talamala
unzip -o talamala-stage-D-registration.zip
php backend/bin/http_smoke.php   # expect PASS=32
cd backend && php -S 127.0.0.1:8080 -t public public/router.php
# browser: http://127.0.0.1:8080/otp-demo.html
```

Commit (scoped files only):

```bash
git add \
  frontend/customer/src/api/auth.ts \
  frontend/customer/src/screens/auth/RegistrationScreen.tsx \
  frontend/customer/src/AppOtpFlow.tsx \
  backend/public/otp-demo.html \
  docs/00-master/STAGE_D_REGISTRATION.md
git commit -m "feat(stage-D): registration form after OTP registration_required"
git push
```
