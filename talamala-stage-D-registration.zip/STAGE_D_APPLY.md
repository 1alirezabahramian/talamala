# Stage D apply

```bash
cd /path/to/talamala
unzip -o talamala-stage-D-registration.zip
php backend/bin/http_smoke.php   # PASS=32
cd backend && php -S 127.0.0.1:8080 -t public public/router.php
# http://127.0.0.1:8080/otp-demo.html
# fake Jibit match: mobile 09121234567 + national_code 0012345678
```

See STAGE_D_PATHS.md for why paths differ from components/auth/… style.
