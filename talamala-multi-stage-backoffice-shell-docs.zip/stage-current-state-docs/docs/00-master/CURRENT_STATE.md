# Talamala — Current State (2026-08-14)

## HTTP smoke
`php backend/bin/http_smoke.php` → **PASS=32 FAIL=0**

Includes: tenant isolation (demo + other + unknown), OTP rate-limit + cross-tenant isolation,
full identity vertical, custody lifecycle, order accept+idempotency, production bearer hardening.

## OpenAPI
v1.3.0 aligned with working routes (429, register, rotate, custody ready/deliver).

## Frontend verticals (local / structure)

### Customer
| Capability | Status | Entry |
|------------|--------|--------|
| OTP request/verify | DONE | `AppOtpFlow`, `otp-demo.html` |
| Registration after `registration_required` | DONE | `RegistrationScreen` |
| Assets (Kimia Read) | DONE | `AssetsScreen`, `assets-demo.html` |
| Custody list (Amanat read) | DONE | `CustodyListScreen`, `custody-demo.html` |
| Orders list | DONE | `OrdersListScreen` |
| Order accept (`quote_id`, settlement blocked) | DONE | `OrderAcceptScreen`, `order-demo.html` |
| CustomerShell tabs | DONE | `CustomerShell.tsx` |

### Backoffice
| Capability | Status | Entry |
|------------|--------|--------|
| Staff login + password rotate | screens in delivery / shell | `StaffLoginScreen`, `StaffRotateScreen` |
| Registration queue + approve | DONE | `RegistrationQueueScreen`, `admin-reg-demo.html` |
| Custody ops receive→ready→deliver | DONE | `CustodyOpsScreen`, `admin-custody-demo.html` |
| BackofficeShell | shell composes queue + custody | `BackofficeShell.tsx` |

## Working vertical (in-memory)

```
OTP → verify → register (Jibit gate) → staff approve
    → bind Kimia account id (service/smoke; no public bind HTTP UI)
    → GET /assets
Custody: receive → ready → delivered
Order: seed fixture quote (dev) → accept (idempotent) → settlement BLOCKED
```

## Explicitly BLOCKED BY GROUND TRUTH
- Live price provider / quote coefficients (GT-004)
- Kimia write / settlement (GT-003)
- Payment gateways (GT-006)
- Live SMS.ir / Jibit credentials (GT-008/009)

## Local run
```bash
cd backend
php bin/http_smoke.php
php -S 127.0.0.1:8080 -t public public/router.php
# demos under /otp-demo.html /assets-demo.html /custody-demo.html
# /order-demo.html /admin-reg-demo.html /admin-custody-demo.html
```

Host: `demo.local` via `X-Talamala-Host`.
