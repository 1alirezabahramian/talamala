/**
 * Mandatory first-login password rotation.
 */

import { useState, type FormEvent } from 'react';
import { staffLogin, staffRotatePassword } from '../api/auth';

export type StaffRotateScreenProps = {
  staffId: string;
  username: string;
  currentPassword: string;
  token?: string;
  onRotated: (accessToken: string) => void;
};

export function StaffRotateScreen(props: StaffRotateScreenProps) {
  const [newPassword, setNewPassword] = useState('ChangeMe-Now-2');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (newPassword.length < 8) {
      setError('رمز جدید حداقل ۸ کاراکتر');
      return;
    }
    setLoading(true);
    try {
      const rot = await staffRotatePassword(
        props.staffId,
        props.currentPassword,
        newPassword,
        props.token,
      );
      if (!rot.ok) {
        setError(rot.message || rot.error || 'چرخش رمز ناموفق');
        return;
      }
      // Re-login for clean session after rotate
      const login = await staffLogin(props.username, newPassword);
      if (!login.ok || !login.data.access_token) {
        setError('ورود مجدد پس از چرخش ناموفق');
        return;
      }
      props.onRotated(login.data.access_token);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="tal-screen tal-staff-rotate" dir="rtl" lang="fa">
      <header className="tal-header">
        <h1>تغییر رمز اجباری</h1>
        <p className="tal-muted">اولین ورود — قبل از دسترسی به صف و امانت</p>
      </header>
      <form onSubmit={onSubmit} className="tal-form" noValidate>
        <label htmlFor="new_password">رمز جدید</label>
        <input
          id="new_password"
          type="password"
          dir="ltr"
          autoComplete="new-password"
          value={newPassword}
          disabled={loading}
          onChange={(e) => setNewPassword(e.target.value)}
        />
        {error ? (
          <p className="tal-error" role="alert">
            {error}
          </p>
        ) : null}
        <button type="submit" disabled={loading}>
          {loading ? '…' : 'ثبت رمز جدید'}
        </button>
      </form>
    </div>
  );
}
