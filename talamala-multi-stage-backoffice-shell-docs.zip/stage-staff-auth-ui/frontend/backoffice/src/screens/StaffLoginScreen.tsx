/**
 * Staff login. On must_change_password, parent should show StaffRotateScreen.
 */

import { useState, type FormEvent } from 'react';
import { staffLogin } from '../api/auth';

export type StaffLoginSuccess = {
  staffId: string;
  accessToken: string;
  mustChangePassword: boolean;
  username: string;
  password: string;
};

export type StaffLoginScreenProps = {
  onSuccess: (session: StaffLoginSuccess) => void;
};

export function StaffLoginScreen(props: StaffLoginScreenProps) {
  const [username, setUsername] = useState('operator');
  const [password, setPassword] = useState('ChangeMe-Now-1');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await staffLogin(username.trim(), password);
      if (!res.ok) {
        setError(res.message || res.error || 'ورود ناموفق');
        return;
      }
      const token = res.data.access_token;
      if (!token) {
        setError('access_token صادر نشد');
        return;
      }
      props.onSuccess({
        staffId: res.data.staff_id,
        accessToken: token,
        mustChangePassword: !!res.data.must_change_password,
        username: username.trim(),
        password,
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="tal-screen tal-staff-login" dir="rtl" lang="fa">
      <header className="tal-header">
        <h1>ورود پرسنل</h1>
        <p className="tal-muted">دمو: operator / ChangeMe-Now-1</p>
      </header>
      <form onSubmit={onSubmit} className="tal-form" noValidate>
        <label htmlFor="username">نام کاربری</label>
        <input
          id="username"
          dir="ltr"
          autoComplete="username"
          value={username}
          disabled={loading}
          onChange={(e) => setUsername(e.target.value)}
        />
        <label htmlFor="password">رمز</label>
        <input
          id="password"
          type="password"
          dir="ltr"
          autoComplete="current-password"
          value={password}
          disabled={loading}
          onChange={(e) => setPassword(e.target.value)}
        />
        {error ? (
          <p className="tal-error" role="alert">
            {error}
          </p>
        ) : null}
        <button type="submit" disabled={loading || !username.trim() || !password}>
          {loading ? '…' : 'ورود'}
        </button>
      </form>
    </div>
  );
}
