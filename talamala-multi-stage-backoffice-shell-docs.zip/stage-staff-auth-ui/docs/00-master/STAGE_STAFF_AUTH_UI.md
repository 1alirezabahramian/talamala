# Stage — Staff Login + Password Rotate UI

POST /v1/auth/staff/login
POST /v1/auth/staff/password/rotate (+ X-Staff-Id)
