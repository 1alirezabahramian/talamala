# Stage: Staff Auth UI

## نام مرحله
StaffLoginScreen + StaffRotateScreen

## مسیر دقیق فایل‌ها
- frontend/backoffice/src/screens/StaffLoginScreen.tsx
- frontend/backoffice/src/screens/StaffRotateScreen.tsx
- docs/00-master/STAGE_STAFF_AUTH_UI.md

## فایل‌های قابل Commit
همان سه مسیر

## Commit message
feat(backoffice): staff login + mandatory password rotate screens

## تست لوکال
operator / ChangeMe-Now-1 → must_change_password → rotate → token

## خارج از scope
BackofficeShell · CustodyOps · registration queue wiring · Kimia

## وابستگی
frontend/backoffice/src/api/auth.ts و client.ts (روی main)
