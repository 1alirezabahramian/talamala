# Stage — BackofficeShell

Composes StaffLogin / StaffRotate / RegistrationQueue / CustodyOps.
