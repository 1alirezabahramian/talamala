# Stage: BackofficeShell

## نام مرحله
BackofficeShell navigation

## مسیر دقیق فایل‌ها
- frontend/backoffice/src/BackofficeShell.tsx
- docs/00-master/STAGE_BACKOFFICE_SHELL.md

## فایل‌های قابل Commit
همان دو مسیر

## Commit message
feat(backoffice): BackofficeShell — login/rotate + queue + custody tabs

## تست لوکال
نیاز به StaffLogin/Rotate + RegistrationQueue + CustodyOps روی main

## خارج از scope
Kimia bind HTTP · price · customer screens

## وابستگی
**بعد از** Stage Staff Auth UI این ZIP + صف و CustodyOps موجود روی main
