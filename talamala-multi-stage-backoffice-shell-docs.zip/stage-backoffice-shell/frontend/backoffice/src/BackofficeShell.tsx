/**
 * Backoffice shell: login/rotate → queue | custody tabs.
 * No new APIs. Composes existing screens.
 */

import { useState } from 'react';
import { StaffLoginScreen, type StaffLoginSuccess } from './screens/StaffLoginScreen';
import { StaffRotateScreen } from './screens/StaffRotateScreen';
import { RegistrationQueueScreen } from './screens/RegistrationQueueScreen';
import { CustodyOpsScreen } from './screens/CustodyOpsScreen';

type Tab = 'queue' | 'custody';

type Session = {
  staffId: string;
  token: string;
};

export function BackofficeShell() {
  const [session, setSession] = useState<Session | null>(null);
  const [pendingRotate, setPendingRotate] = useState<StaffLoginSuccess | null>(null);
  const [tab, setTab] = useState<Tab>('queue');

  if (pendingRotate) {
    return (
      <StaffRotateScreen
        staffId={pendingRotate.staffId}
        username={pendingRotate.username}
        currentPassword={pendingRotate.password}
        token={pendingRotate.accessToken}
        onRotated={(accessToken) => {
          setSession({ staffId: pendingRotate.staffId, token: accessToken });
          setPendingRotate(null);
        }}
      />
    );
  }

  if (!session) {
    return (
      <StaffLoginScreen
        onSuccess={(s) => {
          if (s.mustChangePassword) {
            setPendingRotate(s);
            return;
          }
          setSession({ staffId: s.staffId, token: s.accessToken });
        }}
      />
    );
  }

  return (
    <div className="tal-shell tal-backoffice" dir="rtl" lang="fa">
      <nav className="tal-nav">
        <button
          type="button"
          className={tab === 'queue' ? 'active' : ''}
          onClick={() => setTab('queue')}
        >
          صف ثبت‌نام
        </button>
        <button
          type="button"
          className={tab === 'custody' ? 'active' : ''}
          onClick={() => setTab('custody')}
        >
          امانات
        </button>
        <button
          type="button"
          onClick={() => {
            setSession(null);
            setPendingRotate(null);
          }}
        >
          خروج
        </button>
      </nav>
      {tab === 'queue' ? <RegistrationQueueScreen token={session.token} /> : null}
      {tab === 'custody' ? <CustodyOpsScreen token={session.token} /> : null}
    </div>
  );
}
