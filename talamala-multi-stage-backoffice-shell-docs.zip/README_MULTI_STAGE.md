# Multi-stage: Backoffice auth shell + docs

| Order | Folder | Independent? |
|-------|--------|--------------|
| 1 | stage-staff-auth-ui | yes (needs api/auth.ts on main) |
| 2 | stage-backoffice-shell | after stage 1 + queue + custody screens on main |
| 3 | stage-current-state-docs | independent docs |

Copy paths from each stage folder into repo root (strip stage-* prefix).
