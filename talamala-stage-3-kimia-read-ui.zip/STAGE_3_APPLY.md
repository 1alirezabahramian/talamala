# Stage 3 apply — Kimia Read UI only

## Commit these files only

```
frontend/customer/src/api/assets.ts
frontend/customer/src/screens/assets/AssetsScreen.tsx
backend/public/assets-demo.html
docs/00-master/STAGE_3_KIMIA_READ_UI.md
```

```bash
unzip -o talamala-stage-3-kimia-read-ui.zip
php backend/bin/http_smoke.php   # PASS=32 (no backend change)
git add \
  frontend/customer/src/api/assets.ts \
  frontend/customer/src/screens/assets/AssetsScreen.tsx \
  backend/public/assets-demo.html \
  docs/00-master/STAGE_3_KIMIA_READ_UI.md
git commit -m "feat(stage-3): customer assets UI — Kimia Read GET /v1/customer/assets"
```

Do not commit STAGE_3_APPLY.md unless you want it.
