# MANIFEST — SPA serve + CORS + ops counters

## Commit-allowed
| Path | Change |
|------|--------|
| `backend/public/router.php` | Serve `/app/customer` + `/app/backoffice` from Vite dist; traversal-safe |
| `backend/bin/cors_smoke.php` | **New** PASS=10 |
| `backend/bin/spa_router_smoke.php` | **New** dist + traversal checks |
| `backend/app/Http/Kernel.php` | ops counters on readyz |
| `.github/workflows/ci.yml` | cors-smoke job |
| `docs/00-master/CURRENT_STATE.md` | updated |
| `docs/00-master/STAGE_SPA_CORS_OPS.md` | **New** |
| `docs/00-master/LOCAL_RUN.md` | SPA mount + CORS env |

## Not committed
- `frontend/*/dist` (build artifact; run `npm run build`)
- node_modules

## Expected
```text
php backend/bin/http_smoke.php       → PASS=41 FAIL=0
php backend/bin/persist_smoke.php    → PASS=9 FAIL=0
php backend/bin/cors_smoke.php       → PASS=10 FAIL=0
php backend/bin/openapi_parity_check.php → parity OK
# after build:
php backend/bin/spa_router_smoke.php → PASS=6 FAIL=0
```

## Forbidden (unchanged)
Kimia Write / Settlement / Payment / Pricing / Catalog / Delta blind port
