# MANIFEST — Maintenance purge + shell CSS (multi-step)

## Commit-allowed order
1. SessionStore + Sqlite/InMemory purgeExpired
2. SqliteIdempotencyRegistry::purgeExpired + SqliteRateLimiter::purgeExpired
3. SqliteMaintenance **New**
4. Kernel readyz → ops.purged
5. maintenance_smoke.php **New** PASS=7
6. CI maintenance-smoke + check.php
7. frontend/customer styles.css + main import
8. docs

## Expected
```text
php backend/bin/maintenance_smoke.php → PASS=7 FAIL=0
php backend/bin/http_smoke.php → PASS=43 FAIL=0
php backend/bin/check.php → ALL CHECKS PASSED
```
