# MANIFEST — talamala-batch-0.3.2-hardening-20260816

**Base HEAD:** 3c1d21c  
**VERSION:** 0.3.2-phase1  
**Scope:** Multi-stage Phase-1 hardening pack (no Ground Truth / no financial invent)

## Stages in this ZIP

| Stage | What |
|-------|------|
| A | Permissions-Policy on HTML (`router.php`) + JSON API (`SecurityHeaders.php`) |
| B | `cors_smoke` PASS 10→**11** (Permissions-Policy assert) |
| C | `robots.txt` blocks demos, `/v1/dev/`, `/app/`, `/readyz` |
| D | `landing_smoke` PASS 13→**16** (CSP + Permissions-Policy + robots) |
| E | `check.php` includes `spa_router_smoke` |
| F | README + CURRENT_STATE + OPERATORS + LOCAL_RUN aligned |
| G | `.env.example` documents `TALAMALA_BUILD_SHA` |
| H | Capability Ledger CAP-023 / CAP-024 |
| I | CI gates: cors=11, landing=16 |
| J | VERSION **0.3.2-phase1** |

## Commit-allowed paths
- `.github/workflows/ci.yml`
- `.env.example`
- `VERSION`
- `README.md`
- `backend/app/Http/SecurityHeaders.php`
- `backend/bin/check.php`
- `backend/bin/cors_smoke.php`
- `backend/bin/landing_smoke.php`
- `backend/public/robots.txt`
- `backend/public/router.php`
- `docs/00-master/CURRENT_STATE.md`
- `docs/00-master/LOCAL_RUN.md`
- `docs/00-master/OPERATORS.md`
- `docs/00-master/STAGE_BATCH_0_3_2_HARDENING.md`
- `docs/traceability/CAPABILITY_LEDGER.md`

## Expected tests
```text
php backend/bin/check.php         → ALL CHECKS PASSED
php backend/bin/http_smoke.php    → PASS=49 FAIL=0
php backend/bin/cors_smoke.php    → PASS=11 FAIL=0
php backend/bin/landing_smoke.php → PASS=16 FAIL=0
php backend/bin/spa_router_smoke.php → PASS=6 FAIL=0
cat VERSION                       → 0.3.2-phase1
```

## CI required gates
php-syntax · http(49) · persist(9) · cors(**11**) · logger(8) · maintenance(7) · spa(6) · landing(**16**) · openapi-parity · secret-scan  
frontend-typecheck = optional

## Non-goals
Kimia Write · Pricing · Settlement · Payment · Delta blind port · durable tenant resolver
