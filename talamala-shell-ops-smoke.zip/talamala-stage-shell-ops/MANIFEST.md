# MANIFEST — CustomerShell wire + ops smokes

## Commit-allowed (order)
1. `frontend/customer/src/AppOtpFlow.tsx` — shell after authenticated
2. `frontend/customer/index.html` — minimal nav CSS
3. `backend/bin/http_smoke.php` — ops checks → PASS=43
4. `.github/workflows/ci.yml` — gate PASS=43
5. docs + LOCAL_RUN

## Expected
```text
php backend/bin/http_smoke.php → PASS=43 FAIL=0
npm run typecheck (customer) → PASS
```

## Forbidden
Kimia Write / Payment / Pricing / Delta
