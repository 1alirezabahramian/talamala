# Stage: Customer Shell

## نام مرحله
CustomerShell (tab navigation)

## مسیر دقیق فایل‌ها
- frontend/customer/src/CustomerShell.tsx
- docs/00-master/STAGE_CUSTOMER_SHELL.md

## فایل‌های قابل Commit
همان دو مسیر

## Commit message
feat(customer): CustomerShell tabs — assets / custody / orders / accept

## تست لوکال
نیاز به import صفحات قبلی روی main (Assets, Custody, Orders, Accept)

## خارج از scope
routing library · auth bootstrap کامل · price · Kimia Write

## وابستگی
- Stage 3 Assets UI
- Custody Read UI
- Orders Read UI
- Order Accept UI
Commit این Stage را بعد از سه Stage قبلی بزن.
