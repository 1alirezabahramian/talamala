# Multi-stage delivery (independent commits)

| Order | Folder | Commit after |
|-------|--------|--------------|
| 1 | stage-orders-read/ | independent |
| 2 | stage-order-accept/ | independent (uses client.ts) |
| 3 | stage-customer-shell/ | after 1+2 + assets + custody on main |

Each folder has STAGE.md with exact commit paths and message.
Copy files from each stage folder to repo root paths (paths inside folders are repo-relative).
