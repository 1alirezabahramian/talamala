# Stage: Order Accept UI

## نام مرحله
Customer Order Accept (quote_id only; settlement blocked)

## مسیر دقیق فایل‌ها
- frontend/customer/src/api/orderAccept.ts
- frontend/customer/src/screens/orders/OrderAcceptScreen.tsx
- backend/public/order-demo.html
- docs/00-master/STAGE_ORDER_ACCEPT_UI.md

## فایل‌های قابل Commit
همان چهار مسیر

## Commit message
feat(customer): order accept UI — quote_id + settlement blocked_by_ground_truth

## تست لوکال
cd backend && php -S 127.0.0.1:8080 -t public public/router.php
# http://127.0.0.1:8080/order-demo.html
# customer_id + seed fixture + accept

## خارج از scope
live price provider · Kimia Write · settlement execution · invent coefficients

## وابستگی
client.ts روی main؛ برای list بعد از accept می‌توان Stage Orders Read را جدا commit کرد
