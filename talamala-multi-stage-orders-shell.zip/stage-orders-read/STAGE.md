# Stage: Orders Read UI

## نام مرحله
Customer Orders List (read-only)

## مسیر دقیق فایل‌ها
- frontend/customer/src/api/orders.ts
- frontend/customer/src/screens/orders/OrdersListScreen.tsx
- docs/00-master/STAGE_ORDERS_READ_UI.md

## فایل‌های قابل Commit
همان سه مسیر بالا

## Commit message
feat(customer): orders list UI — GET /v1/customer/orders read-only

## تست لوکال
php backend/bin/http_smoke.php
# نیاز به customer با order قبلی (smoke می‌سازد)

## خارج از scope
price feed · seed-quote UI · accept · Kimia Write · settlement

## وابستگی
frontend/customer/src/api/client.ts (روی main از Stage C)
