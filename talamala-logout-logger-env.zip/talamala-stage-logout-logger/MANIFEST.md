# MANIFEST — Logout UI + Logger stream + env (multi-step)

## Commit-allowed (suggested order)
1. `backend/app/Infrastructure/Logging/StructuredLogger.php` — fromEnv
2. `backend/app/Http/Kernel.php` — wire fromEnv
3. `backend/bin/logger_smoke.php` — **New** PASS=7
4. `frontend/customer/src/AppOtpFlow.tsx` — logout button
5. `frontend/backoffice/src/AppBackoffice.tsx` — logout button
6. `.env.example` — **New**
7. `backend/bin/check.php` — aggregate smokes
8. `.github/workflows/ci.yml` — logger-smoke job
9. docs

## Expected tests
```text
php backend/bin/logger_smoke.php → PASS=7 FAIL=0
php backend/bin/http_smoke.php   → PASS=41 FAIL=0
php backend/bin/check.php        → ALL CHECKS PASSED
cd frontend/customer && npm run typecheck
cd frontend/backoffice && npm run typecheck
```

## Not included
Kimia Write / Payment / Pricing / Delta
