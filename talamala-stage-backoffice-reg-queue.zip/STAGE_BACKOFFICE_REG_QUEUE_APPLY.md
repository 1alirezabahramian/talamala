# Apply — Backoffice Registration Queue

## Commit these files only

```
frontend/backoffice/src/api/client.ts
frontend/backoffice/src/api/auth.ts
frontend/backoffice/src/api/registrations.ts
frontend/backoffice/src/screens/RegistrationQueueScreen.tsx
backend/public/admin-reg-demo.html
docs/00-master/STAGE_BACKOFFICE_REG_QUEUE.md
```

```bash
unzip -o talamala-stage-backoffice-reg-queue.zip
php backend/bin/http_smoke.php

git add \
  frontend/backoffice/src/api/client.ts \
  frontend/backoffice/src/api/auth.ts \
  frontend/backoffice/src/api/registrations.ts \
  frontend/backoffice/src/screens/RegistrationQueueScreen.tsx \
  backend/public/admin-reg-demo.html \
  docs/00-master/STAGE_BACKOFFICE_REG_QUEUE.md
git commit -m "feat(backoffice): registration queue list + approve (Limited → Active)"
```

Local: http://127.0.0.1:8080/admin-reg-demo.html
