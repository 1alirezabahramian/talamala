# MANIFEST — Persistence-1 (SQLite)

**Date:** 2026-08-15  
**Smoke:** http PASS=33 · persist PASS=6

## Commit-allowed

- `backend/app/Infrastructure/Persistence/Sqlite/` (all)
- `backend/app/Http/Kernel.php` (wired to Sqlite repos)
- `backend/bin/persist_smoke.php`
- `backend/.env.example` (`TALAMALA_DB_PATH`)
- `docs/00-master/STAGE_PERSISTENCE_1.md`
- `docs/00-master/CURRENT_STATE.md`
- `docs/00-master/LOCAL_RUN.md`
- `docs/traceability/CAPABILITY_LEDGER.md` (note)

## Bundled-only / not this stage

- frontend, openapi, AGENTS, full backend tree beyond paths above

## Notes

- Requires `pdo_sqlite` PHP extension
- No Kimia Write / payment / local balance ledger
- Sessions & audit still InMemory → Persistence-2
