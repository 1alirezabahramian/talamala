# MANIFEST — Rate limiter durable + Thin Vite

## Commit-allowed

### Backend
| Path | Change |
|------|--------|
| `backend/app/Infrastructure/Security/RateLimiter.php` | **New** interface |
| `backend/app/Infrastructure/Security/InMemoryRateLimiter.php` | implements interface |
| `backend/app/Infrastructure/Persistence/Sqlite/SqliteRateLimiter.php` | **New** durable OTP limiter |
| `backend/app/Infrastructure/Persistence/Sqlite/SqliteConnection.php` | `rate_limits` table |
| `backend/app/Http/Kernel.php` | wire SqliteRateLimiter |

### Frontend
| Path | Change |
|------|--------|
| `frontend/customer/package.json` + lock | Vite/React/TS toolchain |
| `frontend/customer/tsconfig.json` | **New** |
| `frontend/customer/vite.config.ts` | **New** (proxy to :8080) |
| `frontend/customer/index.html` | **New** |
| `frontend/customer/src/main.tsx` | **New** entry → AppOtpFlow |
| `frontend/backoffice/package.json` + lock | same toolchain |
| `frontend/backoffice/tsconfig.json` | **New** |
| `frontend/backoffice/vite.config.ts` | **New** |
| `frontend/backoffice/index.html` | **New** |
| `frontend/backoffice/src/main.tsx` | **New** |
| `frontend/backoffice/src/AppBackoffice.tsx` | **New** login→rotate→queue |

### Meta
| Path | Change |
|------|--------|
| `.gitignore` | **New** node_modules/dist/sqlite |
| `.github/workflows/ci.yml` | `frontend-typecheck` job |
| `docs/00-master/CURRENT_STATE.md` | updated |
| `docs/00-master/STAGE_THIN_VITE.md` | **New** |

## Bundled-only
- This MANIFEST + ZIP

## Not included / not invented
- Kimia Write / Settlement / Payment / Pricing / Catalog
- Blind port of GoldPlatform V2 Delta
- Changing existing screen business contracts
- OTP/rate limits remain 5/300s (existing OpenAPI)

## Expected tests
```text
php backend/bin/http_smoke.php            → PASS=33 FAIL=0
php backend/bin/persist_smoke.php         → PASS=9 FAIL=0
php backend/bin/openapi_parity_check.php  → parity OK
cd frontend/customer && npm ci && npm run typecheck && npm run build
cd frontend/backoffice && npm ci && npm run typecheck && npm run build
```

## CI jobs
php-syntax · http-smoke · persist-smoke · openapi-parity · secret-scan · **frontend-typecheck**
