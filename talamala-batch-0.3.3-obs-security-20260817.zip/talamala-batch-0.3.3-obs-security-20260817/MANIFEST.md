# MANIFEST — talamala-batch-0.3.3-obs-security-20260817

**Base HEAD:** e9dd2e6 (0.3.2-phase1)  
**VERSION:** 0.3.3-phase1  
**Scope:** Multi-stage observability + security pack (no Ground Truth / no financial invent)

## Stages in this ZIP

| # | Stage | Detail |
|---|--------|--------|
| A | X-Correlation-Id | `index.php` always emits header; preserves client value |
| B | Cross-Domain-Policies | `none` on HTML router + JSON SecurityHeaders |
| C | cors_smoke | + referrer + cross-domain → PASS **13** |
| D | landing_smoke | + cross-domain assert → PASS **17** |
| E | http_smoke negatives | `unknown_path_404` + `healthz_no_tenant` → PASS **51** |
| F | domain_smoke in check | `bin/smoke.php` in aggregate `check.php` |
| G | Makefile | `make version` |
| H | CI gates | http 51 · cors 13 · landing 17 |
| I | Docs / README / Ledger | CAP-025 / CAP-026 · CURRENT_STATE · OPERATORS · LOCAL_RUN |
| J | VERSION | **0.3.3-phase1** |

## Commit-allowed paths
- `.github/workflows/ci.yml`
- `.env.example` (unchanged content ok if already present)
- `VERSION` · `README.md` · `Makefile`
- `backend/public/index.php` · `backend/public/router.php` · `backend/public/robots.txt`
- `backend/app/Http/SecurityHeaders.php`
- `backend/bin/http_smoke.php` · `cors_smoke.php` · `landing_smoke.php` · `check.php`
- `docs/00-master/CURRENT_STATE.md` · `OPERATORS.md` · `LOCAL_RUN.md`
- `docs/00-master/STAGE_BATCH_0_3_3_OBS_SECURITY.md`
- `docs/traceability/CAPABILITY_LEDGER.md`

## Expected tests
```text
php backend/bin/check.php         → ALL CHECKS PASSED
php backend/bin/http_smoke.php    → PASS=51 FAIL=0
php backend/bin/cors_smoke.php    → PASS=13 FAIL=0
php backend/bin/landing_smoke.php → PASS=17 FAIL=0
php backend/bin/smoke.php         → PASS=8 FAIL=0
cat VERSION                       → 0.3.3-phase1
```

## CI required gates
php-syntax · http(**51**) · persist(9) · cors(**13**) · logger(8) · maintenance(7) · spa(6) · landing(**17**) · openapi-parity · secret-scan  
frontend-typecheck = optional

## Non-goals
Kimia Write · Pricing · Settlement · Payment · Delta blind port · durable tenant resolver
