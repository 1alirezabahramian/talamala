# MANIFEST — Landing hub + Operators (multi-step)

## Commit order
1. `backend/public/landing.html` **New**
2. `backend/public/router.php` — `/` → landing
3. `docs/00-master/OPERATORS.md` **New**
4. `README.md` — pointer
5. `backend/bin/landing_smoke.php` **New** PASS=8
6. CI landing-smoke + check.php
7. `robots.txt` + docs

## Expected
```text
php backend/bin/landing_smoke.php → PASS=8 FAIL=0
php backend/bin/http_smoke.php    → PASS=43 FAIL=0
php backend/bin/check.php         → ALL CHECKS PASSED
```
