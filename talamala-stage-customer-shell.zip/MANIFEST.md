# MANIFEST — Stage Customer Shell

**Date:** 2026-08-15  
**Smoke:** PASS=33 FAIL=0 (no backend route change in this stage)

## Commit-allowed

- `backend/public/customer-shell-demo.html` — **new**
- `backend/public/otp-demo.html` — link-in to shell after identity
- `docs/00-master/STAGE_CUSTOMER_SHELL.md`
- `docs/00-master/CURRENT_STATE.md`
- `frontend/customer/src/CustomerShell.tsx` (already present; included for parity)

## Not in this ZIP / not for this commit

- backend app/Kernel (unchanged this stage)
- frontend/backoffice
- AGENTS.md / README root guides

## Contracts used (existing only)

GET /v1/customer/assets  
GET /v1/customer/custody  
GET /v1/customer/orders  
POST /v1/customer/orders/accept (+ Idempotency-Key)  
POST /v1/dev/seed-quote (dev only)

## Verify

```bash
cd backend && php bin/http_smoke.php
php -S 127.0.0.1:8080 -t public public/router.php
# http://127.0.0.1:8080/customer-shell-demo.html
```
