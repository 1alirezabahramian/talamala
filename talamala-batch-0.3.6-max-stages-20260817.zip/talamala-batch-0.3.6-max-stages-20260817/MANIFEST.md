# MANIFEST — talamala-batch-0.3.6-max-stages-20260817

**Base HEAD:** 658405a (0.3.5-phase1)  
**VERSION:** 0.3.6-phase1  
**Scope:** Maximized safe multi-stage pack (contracts + DX + frontend correlation)

## Stages (13+)
1. otp_invalid_purpose → 422
2. otp_verify_fields_required → 422
3. register_validation_required → 400
4. register_already_registered → 400
5. otp_request_wrong_method → 404
6. healthz_service_name
7. Customer client X-Correlation-Id
8. Backoffice client X-Correlation-Id
9. Makefile `help`
10. robots Allow: /healthz
11. OpenAPI auth OTP 422
12. http_smoke PASS 59 → **65** + CI
13. VERSION 0.3.6-phase1 + docs + CAP-030/031

## Commit-allowed
- `.github/workflows/ci.yml`
- `VERSION` · `README.md` · `Makefile`
- `backend/bin/http_smoke.php`
- `backend/public/robots.txt`
- `frontend/customer/src/api/client.ts`
- `frontend/backoffice/src/api/client.ts`
- `openapi/auth-v1.openapi.yaml`
- `docs/00-master/CURRENT_STATE.md` · `OPERATORS.md` · `LOCAL_RUN.md`
- `docs/00-master/STAGE_BATCH_0_3_6_CONTRACT_DX.md`
- `docs/traceability/CAPABILITY_LEDGER.md`

## Expected
```text
php backend/bin/http_smoke.php → PASS=65 FAIL=0
php backend/bin/check.php      → ALL CHECKS PASSED
```

## Non-goals
Kimia Write · Pricing · Settlement · Payment · Delta · durable tenant resolver
