# MANIFEST — kimia-verify-resume-preflight

**No Write. No domain feature. Resume point only.**

## Files
- `docs/providers/official/KIMIA_WRITE_VERIFICATION_RESUME.md` — normative resume + default-deny rules
- `backend/bin/kimia_preflight_readonly.php` — P0–P6 read-only preflight
- `docs/00-master/CURRENT_STATE.md` — pointer
- `.env.example` — Kimia env keys (empty)

## Run when Kimia reachable
```bash
export KIMIA_BASE_URL=...
export KIMIA_USERNAME=...
export KIMIA_PASSWORD=...
php backend/bin/kimia_preflight_readonly.php
# evidence → var/kimia-verify/ (gitignored)
```

Write remains blocked until Owner reviews evidence and sets enable flag.
