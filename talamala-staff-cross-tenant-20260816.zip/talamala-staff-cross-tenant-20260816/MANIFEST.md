# MANIFEST — talamala-staff-cross-tenant-20260816

**Base HEAD:** ebc84da (Gap 1–2 already on main)  
**Date:** 2026-08-16  
**Scope:** Safe isolation negative — staff Bearer cross-tenant fail-closed smoke + CI gate 49

## Commit-allowed
| Path | Action |
|------|--------|
| `backend/bin/http_smoke.php` | Patch — `session_staff_cross_tenant_rejected` (PASS 48→49) |
| `.github/workflows/ci.yml` | Patch — http-smoke gate PASS=49 |
| `docs/00-master/CURRENT_STATE.md` | Replace |
| `docs/00-master/OPERATORS.md` | Patch — expect http 49 |
| `docs/00-master/LOCAL_RUN.md` | Patch — expect http 49 |
| `docs/00-master/STAGE_STAFF_CROSS_TENANT_NEGATIVE.md` | New |

## Bundled-only
- This MANIFEST.md

## Expected tests
```text
php backend/bin/http_smoke.php → PASS=49 FAIL=0
php backend/bin/check.php      → ALL CHECKS PASSED
```

## CI jobs required for green SHA
php-syntax · http-smoke (**49**) · persist (9) · cors (10) · logger (8) · maintenance (7) · spa-router · landing (13) · openapi-parity · secret-scan  
frontend-typecheck = optional

## Non-goals
- No financial invent · no Kimia write · no Delta port · no tenant resolver persistence
