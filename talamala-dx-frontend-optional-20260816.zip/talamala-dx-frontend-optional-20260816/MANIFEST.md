# MANIFEST — talamala-dx-frontend-optional-20260816

**Base HEAD (read-only reference):** ab6c4d76bd640cce7b0e2a0d9305f8d77686f0e1  
**Date:** 2026-08-16  
**Scope:** Safe engineering — Gap #1 (frontend CI optional) + Gap #2 (DX LOCAL_RUN align)

## Commit-allowed (apply to repo)
| Path | Action |
|------|--------|
| `.github/workflows/ci.yml` | Patch — frontend-typecheck `continue-on-error: true`, report text updated |
| `Makefile` | Patch — add `frontend-typecheck` + `frontend-build` |
| `docs/00-master/CURRENT_STATE.md` | Replace — date + optional frontend note |
| `docs/00-master/OPERATORS.md` | Replace — SPA section + advisory CI note |
| `docs/00-master/LOCAL_RUN.md` | Replace — unified operator guide (env table, demos, make targets) |
| `docs/00-master/STAGE_FRONTEND_CI_OPTIONAL.md` | New |
| `docs/00-master/STAGE_DX_LOCAL_RUN_ALIGN.md` | New |

## Bundled-only
- This MANIFEST.md

## Expected tests (no regression)
```text
php backend/bin/check.php          → ALL CHECKS PASSED
php backend/bin/http_smoke.php     → PASS=48 FAIL=0
php backend/bin/landing_smoke.php  → PASS=13 FAIL=0
# optional (Node):
make frontend-typecheck
```

## CI jobs required for green SHA
php-syntax · http-smoke (48) · persist (9) · cors (10) · logger (8) · maintenance (7) · spa-router · landing (13) · openapi-parity · secret-scan  

frontend-typecheck = **optional / continue-on-error** (advisory only).

## Non-goals / not touched
- No financial / Kimia / pricing / payment invent
- No tenant resolver persistence
- No change to smoke PASS counts or OpenAPI contracts
- No Delta / Store Instance port
