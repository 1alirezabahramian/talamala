# Kimia Live Preflight Evidence Receipt

**Recorded:** 2026-08-18  
**Source:** Owner / ops report — dedicated runner  
**Write executed:** **NO** (`write_attempted=false`)  
**Write authorized for execution tonight:** **NO**

## Runner

| Field | Value |
|-------|--------|
| Service | `talamala-kimia-runner` (Chabokan, Iran) |
| Purpose | Same-environment live reachability + Read preflight |

## Preflight results (reported PASS ×2)

| Step | Result |
|------|--------|
| Live connectivity | PASS |
| Swagger HTTP | **200** |
| Swagger `info.version` | **v1** |
| Live Swagger SHA-256 | `be0fb0c6897015e238ef9dd58115b8502cf6f83feb868c91cff19377dfbb5cea` |
| Auth (Basic Read) | PASS |
| Account 350 | PASS |
| Balance baseline (350) | PASS |
| Transactions baseline (350) | PASS |
| Aggregate | **PREFLIGHT_OK** (two separate executions) |

## Contract posture

- Existing archived Swagger / analysis docs remain the **contract reference** for documented API shape.
- Tonight’s evidence establishes **live reachability + same-environment verification**, not a replacement of prior API analysis.
- Any material live-vs-archive delta on Create/Trade/Cash paths still requires **Owner decision** before Write.
- Full raw evidence bodies stay on the runner under gitignored paths (e.g. `var/kimia-verify/`); secrets must not appear in Git.

## Gate status

```text
Preflight Read-Only ........ OPEN (satisfied on runner)
Write Verification gate ... CLOSED (default-deny)
Phase-1 product freeze .... STILL FROZEN at 0.3.8-phase1
```

## Resume instruction

When Owner authorizes the **bounded** live Write test, resume **from the Kimia Write Verification gate** on `talamala-kimia-runner`, using this preflight evidence — do not re-litigate connectivity from scratch, and do not widen scope beyond:

- ≤5 experimental creates (Swagger-only fields)
- account `350`: exactly 1 buy, 1 sell, 1 receive, 1 pay
- before/after balance + transactions + full request/response capture
- mandatory stop after those four financial ops
