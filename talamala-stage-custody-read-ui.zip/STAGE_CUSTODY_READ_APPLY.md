# Apply — Custody Read UI

```bash
unzip -o talamala-stage-custody-read-ui.zip
php backend/bin/http_smoke.php

git add \
  frontend/customer/src/api/custody.ts \
  frontend/customer/src/screens/custody/CustodyListScreen.tsx \
  backend/public/custody-demo.html \
  docs/00-master/STAGE_CUSTODY_READ_UI.md
git commit -m "feat: customer custody list UI — GET /v1/customer/custody read-only"
```

Local: http://127.0.0.1:8080/custody-demo.html
